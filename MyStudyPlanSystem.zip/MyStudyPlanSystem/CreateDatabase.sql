IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'StudyPlanDB')
BEGIN
    CREATE DATABASE StudyPlanDB;
END
GO

USE StudyPlanDB;
GO

IF OBJECT_ID('dbo.Terms', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Terms (
        TermId INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        Name NVARCHAR(50) NOT NULL,
        StartDate DATETIME2 NULL,
        EndDate DATETIME2 NULL
    );
END
GO

IF OBJECT_ID('dbo.ClassGroups', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.ClassGroups (
        ClassGroupId INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        Name NVARCHAR(50) NOT NULL,
        TermId INT NULL,
        CONSTRAINT FK_ClassGroups_Terms FOREIGN KEY (TermId) REFERENCES dbo.Terms(TermId)
    );

    CREATE UNIQUE INDEX IX_ClassGroups_Name ON dbo.ClassGroups(Name);
END
GO

IF OBJECT_ID('dbo.MajorOptions', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.MajorOptions (
        MajorOptionId INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL
    );

    CREATE UNIQUE INDEX IX_MajorOptions_Name ON dbo.MajorOptions(Name);
END
GO

IF OBJECT_ID('dbo.GradeOptions', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.GradeOptions (
        GradeOptionId INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        Name NVARCHAR(50) NOT NULL
    );

    CREATE UNIQUE INDEX IX_GradeOptions_Name ON dbo.GradeOptions(Name);
END
GO

IF OBJECT_ID('dbo.Users', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Users (
        UserId INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
        Username NVARCHAR(50) NOT NULL,
        Password NVARCHAR(100) NOT NULL,
        RealName NVARCHAR(50) NOT NULL,
        Role NVARCHAR(20) NOT NULL,
        Major NVARCHAR(100) NULL,
        Grade NVARCHAR(50) NULL,
        ClassName NVARCHAR(50) NULL,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE()
    );

    CREATE UNIQUE INDEX IX_Users_Username ON dbo.Users(Username);
END
GO

IF COL_LENGTH('dbo.Users', 'Grade') IS NULL
BEGIN
    ALTER TABLE dbo.Users ADD Grade NVARCHAR(50) NULL;
END
GO

IF OBJECT_ID('dbo.Courses', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Courses (
        CourseId INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
        CourseCode NVARCHAR(30) NOT NULL,
        CourseName NVARCHAR(100) NOT NULL,
        Description NVARCHAR(500) NULL,
        MaterialPath NVARCHAR(300) NULL,
        TeacherId INT NOT NULL,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_Courses_Users_TeacherId FOREIGN KEY ([TeacherId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );

    CREATE UNIQUE INDEX IX_Courses_CourseCode ON dbo.Courses(CourseCode);
END
GO

IF OBJECT_ID('dbo.CourseTasks', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.CourseTasks (
        TaskId INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
        TaskName NVARCHAR(200) NOT NULL,
        Description NVARCHAR(1000) NULL,
        CourseId INT NOT NULL,
        EstimatedHours INT NOT NULL,
        ResourceUrl NVARCHAR(500) NULL,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_CourseTasks_Courses_CourseId FOREIGN KEY ([CourseId]) REFERENCES [Courses] ([CourseId]) ON DELETE CASCADE
    );
END
GO

IF OBJECT_ID('dbo.StudyPlans', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.StudyPlans (
        PlanId INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
        PlanName NVARCHAR(100) NOT NULL,
        Description NVARCHAR(500) NULL,
        StudentId INT NOT NULL,
        CourseId INT NULL,
        StartDate DATETIME2 NOT NULL,
        EndDate DATETIME2 NOT NULL,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_StudyPlans_Users_StudentId FOREIGN KEY ([StudentId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT FK_StudyPlans_Courses_CourseId FOREIGN KEY ([CourseId]) REFERENCES [Courses] ([CourseId]) ON DELETE SET NULL
    );

    CREATE INDEX IX_StudyPlans_CourseId ON dbo.StudyPlans(CourseId);
END
GO

IF OBJECT_ID('dbo.PlanTasks', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.PlanTasks (
        PlanTaskId INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
        PlanId INT NOT NULL,
        TaskId INT NOT NULL,
        PlannedDate DATETIME2 NOT NULL,
        IsCompleted BIT NOT NULL DEFAULT 0,
        CompletedDate DATETIME2 NULL,
        Notes NVARCHAR(500) NULL,
        CONSTRAINT FK_PlanTasks_StudyPlans_PlanId FOREIGN KEY ([PlanId]) REFERENCES [StudyPlans] ([PlanId]) ON DELETE CASCADE,
        CONSTRAINT FK_PlanTasks_CourseTasks_TaskId FOREIGN KEY ([TaskId]) REFERENCES [CourseTasks] ([TaskId]) ON DELETE NO ACTION
    );
END
GO

IF OBJECT_ID('dbo.Messages', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Messages (
        MessageId INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
        SenderId INT NOT NULL,
        ReceiverId INT NOT NULL,
        Subject NVARCHAR(100) NOT NULL,
        Content NVARCHAR(2000) NOT NULL,
        Category NVARCHAR(50) NULL CONSTRAINT DF_Messages_Category DEFAULT ('General'),
        Reply NVARCHAR(2000) NULL,
        RepliedAt DATETIME2 NULL,
        IsRead BIT NOT NULL DEFAULT 0,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_Messages_Users_SenderId FOREIGN KEY ([SenderId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT FK_Messages_Users_ReceiverId FOREIGN KEY ([ReceiverId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END
GO

IF OBJECT_ID('dbo.MessageReplies', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.MessageReplies (
        MessageReplyId INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        MessageId INT NOT NULL,
        SenderId INT NOT NULL,
        Content NVARCHAR(2000) NOT NULL,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_MessageReplies_Messages FOREIGN KEY (MessageId) REFERENCES dbo.Messages(MessageId) ON DELETE CASCADE,
        CONSTRAINT FK_MessageReplies_Users FOREIGN KEY (SenderId) REFERENCES dbo.Users(UserId) ON DELETE NO ACTION
    );
END
GO

IF OBJECT_ID('dbo.Announcements', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Announcements (
        AnnouncementId INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        Title NVARCHAR(100) NOT NULL,
        Content NVARCHAR(2000) NOT NULL,
        CreatedAt DATETIME2 NOT NULL CONSTRAINT DF_Announcements_CreatedAt DEFAULT (GETDATE()),
        IsActive BIT NOT NULL CONSTRAINT DF_Announcements_IsActive DEFAULT (1)
    );
END
GO

PRINT 'Database schema created successfully.';
GO
