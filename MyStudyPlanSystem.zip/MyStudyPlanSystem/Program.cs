using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using MyStudyPlanSystem.Data;

var builder = WebApplication.CreateBuilder(args);

var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Connection string 'DefaultConnection' is missing.");

builder.Services.AddRazorPages(options =>
{
    options.Conventions.AuthorizeFolder("/Teacher", "RequireTeacherRole");
    options.Conventions.AuthorizeFolder("/Student", "RequireStudentRole");
    options.Conventions.AuthorizePage("/Admin/Settings/Index", "RequireAdminRole");
    options.Conventions.AuthorizePage("/Admin/Users/Index", "RequireAdminOrTeacherRole");
    options.Conventions.AuthorizeFolder("/Messages");
    options.Conventions.AuthorizeFolder("/Account");
    options.Conventions.AllowAnonymousToPage("/Index");
    options.Conventions.AllowAnonymousToPage("/Register");
});

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Index";
        options.Cookie.HttpOnly = true;
        options.Cookie.SameSite = SameSiteMode.Lax;
        options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
    });

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("RequireTeacherRole", policy => policy.RequireRole("Teacher"));
    options.AddPolicy("RequireStudentRole", policy => policy.RequireRole("Student"));
    options.AddPolicy("RequireAdminRole", policy => policy.RequireRole("Admin"));
    options.AddPolicy("RequireAdminOrTeacherRole", policy => policy.RequireRole("Admin", "Teacher"));
});

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(connectionString));

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.EnsureCreated();
    await EnsureLocalSchemaAsync(db);
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();
app.MapRazorPages();
app.Run();

static Task EnsureLocalSchemaAsync(AppDbContext db)
{
    return db.Database.ExecuteSqlRawAsync(
        """
        IF OBJECT_ID('dbo.GradeOptions', 'U') IS NULL
        BEGIN
            CREATE TABLE dbo.GradeOptions (
                GradeOptionId INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
                Name NVARCHAR(50) NOT NULL
            );
        END

        IF OBJECT_ID('dbo.GradeOptions', 'U') IS NOT NULL
            AND NOT EXISTS (
                SELECT 1
                FROM sys.indexes
                WHERE name = 'IX_GradeOptions_Name'
                  AND object_id = OBJECT_ID('dbo.GradeOptions'))
        BEGIN
            CREATE UNIQUE INDEX IX_GradeOptions_Name ON dbo.GradeOptions(Name);
        END

        IF COL_LENGTH('dbo.Users', 'Grade') IS NULL
        BEGIN
            ALTER TABLE dbo.Users ADD Grade NVARCHAR(50) NULL;
        END

        IF OBJECT_ID('dbo.StudyPlans', 'U') IS NOT NULL
            AND COL_LENGTH('dbo.StudyPlans', 'CourseId') IS NULL
        BEGIN
            ALTER TABLE dbo.StudyPlans ADD CourseId INT NULL;
        END

        IF OBJECT_ID('dbo.StudyPlans', 'U') IS NOT NULL
            AND COL_LENGTH('dbo.StudyPlans', 'CourseId') IS NOT NULL
        BEGIN
            EXEC(N'
                ;WITH PlanCourseMap AS (
                    SELECT
                        sp.PlanId,
                        MIN(ct.CourseId) AS CourseId,
                        COUNT(DISTINCT ct.CourseId) AS CourseCount
                    FROM dbo.StudyPlans sp
                    LEFT JOIN dbo.PlanTasks pt ON pt.PlanId = sp.PlanId
                    LEFT JOIN dbo.CourseTasks ct ON ct.TaskId = pt.TaskId
                    GROUP BY sp.PlanId
                )
                UPDATE sp
                SET sp.CourseId = pcm.CourseId
                FROM dbo.StudyPlans sp
                INNER JOIN PlanCourseMap pcm ON pcm.PlanId = sp.PlanId
                WHERE sp.CourseId IS NULL
                  AND pcm.CourseCount = 1
                  AND pcm.CourseId IS NOT NULL;
            ');
        END

        IF OBJECT_ID('dbo.StudyPlans', 'U') IS NOT NULL
            AND COL_LENGTH('dbo.StudyPlans', 'CourseId') IS NOT NULL
            AND NOT EXISTS (
                SELECT 1
                FROM sys.indexes
                WHERE name = 'IX_StudyPlans_CourseId'
                  AND object_id = OBJECT_ID('dbo.StudyPlans'))
        BEGIN
            EXEC(N'CREATE INDEX IX_StudyPlans_CourseId ON dbo.StudyPlans(CourseId);');
        END

        IF OBJECT_ID('dbo.StudyPlans', 'U') IS NOT NULL
            AND COL_LENGTH('dbo.StudyPlans', 'CourseId') IS NOT NULL
            AND NOT EXISTS (
                SELECT 1
                FROM sys.foreign_keys
                WHERE name = 'FK_StudyPlans_Courses_CourseId')
        BEGIN
            EXEC(N'
                ALTER TABLE dbo.StudyPlans
                ADD CONSTRAINT FK_StudyPlans_Courses_CourseId
                FOREIGN KEY (CourseId) REFERENCES dbo.Courses(CourseId) ON DELETE SET NULL;
            ');
        END
        """);
}
