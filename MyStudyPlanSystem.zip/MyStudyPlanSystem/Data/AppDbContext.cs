using Microsoft.EntityFrameworkCore;
using MyStudyPlanSystem.Models;

namespace MyStudyPlanSystem.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<User> Users => Set<User>();
        public DbSet<Course> Courses => Set<Course>();
        public DbSet<CourseTask> CourseTasks => Set<CourseTask>();
        public DbSet<StudyPlan> StudyPlans => Set<StudyPlan>();
        public DbSet<PlanTask> PlanTasks => Set<PlanTask>();
        public DbSet<Message> Messages => Set<Message>();
        public DbSet<MessageReply> MessageReplies => Set<MessageReply>();
        public DbSet<Term> Terms => Set<Term>();
        public DbSet<ClassGroup> ClassGroups => Set<ClassGroup>();
        public DbSet<MajorOption> MajorOptions => Set<MajorOption>();
        public DbSet<GradeOption> GradeOptions => Set<GradeOption>();
        public DbSet<Announcement> Announcements => Set<Announcement>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>()
                .HasIndex(u => u.Username)
                .IsUnique();

            modelBuilder.Entity<Course>()
                .HasIndex(c => c.CourseCode)
                .IsUnique();

            modelBuilder.Entity<ClassGroup>()
                .HasIndex(c => c.Name)
                .IsUnique();

            modelBuilder.Entity<MajorOption>()
                .HasIndex(m => m.Name)
                .IsUnique();

            modelBuilder.Entity<GradeOption>()
                .HasIndex(g => g.Name)
                .IsUnique();

            modelBuilder.Entity<Course>()
                .HasMany(c => c.Tasks)
                .WithOne(t => t.Course)
                .HasForeignKey(t => t.CourseId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Course>()
                .HasOne(c => c.Teacher)
                .WithMany(u => u.Courses)
                .HasForeignKey(c => c.TeacherId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<StudyPlan>()
                .HasOne(p => p.Student)
                .WithMany(u => u.StudyPlans)
                .HasForeignKey(p => p.StudentId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<StudyPlan>()
                .HasOne(p => p.Course)
                .WithMany()
                .HasForeignKey(p => p.CourseId)
                .OnDelete(DeleteBehavior.SetNull);

            modelBuilder.Entity<Message>()
                .HasOne(m => m.Sender)
                .WithMany(u => u.SentMessages)
                .HasForeignKey(m => m.SenderId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Message>()
                .HasOne(m => m.Receiver)
                .WithMany(u => u.ReceivedMessages)
                .HasForeignKey(m => m.ReceiverId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<MessageReply>()
                .HasOne(r => r.Message)
                .WithMany(m => m.Replies)
                .HasForeignKey(r => r.MessageId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<MessageReply>()
                .HasOne(r => r.Sender)
                .WithMany()
                .HasForeignKey(r => r.SenderId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<PlanTask>()
                .HasOne(pt => pt.StudyPlan)
                .WithMany(p => p.PlanTasks)
                .HasForeignKey(pt => pt.PlanId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<PlanTask>()
                .HasOne(pt => pt.CourseTask)
                .WithMany(t => t.PlanTasks)
                .HasForeignKey(pt => pt.TaskId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Term>()
                .HasMany(t => t.Classes)
                .WithOne(c => c.Term)
                .HasForeignKey(c => c.TermId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
