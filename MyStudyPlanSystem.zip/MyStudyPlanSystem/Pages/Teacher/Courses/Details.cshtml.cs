using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MyStudyPlanSystem.Data;
using MyStudyPlanSystem.Models;
using MyStudyPlanSystem.Utils;
using System.Security.Claims;

namespace MyStudyPlanSystem.Pages.Teacher.Courses
{
    [Authorize(Policy = "RequireTeacherRole")]
    public class DetailsModel : PageModel
    {
        private readonly AppDbContext _context;

        public DetailsModel(AppDbContext context)
        {
            _context = context;
        }

        public Course Course { get; set; } = default!;

        [BindProperty]
        public CourseTask NewTask { get; set; } = new CourseTask { TaskName = string.Empty };

        private int CurrentUserId => int.TryParse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value, out var id) ? id : 0;

        public async Task<IActionResult> OnGetAsync(int id)
        {
            return await LoadCourse(id);
        }

        public async Task<IActionResult> OnPostAddTaskAsync(int id)
        {
            NewTask.TaskName = NewTask.TaskName?.Trim() ?? string.Empty;
            NewTask.Description = string.IsNullOrWhiteSpace(NewTask.Description) ? null : NewTask.Description.Trim();
            NewTask.ResourceUrl = ResourceUrlHelper.NormalizeForStorage(NewTask.ResourceUrl);
            if (NewTask.EstimatedHours < 1)
            {
                NewTask.EstimatedHours = 1;
            }

            if (!TryValidateModel(NewTask, nameof(NewTask)))
            {
                return await LoadCourse(id);
            }

            var course = await _context.Courses.FindAsync(id);
            if (course == null)
            {
                return NotFound();
            }

            if (course.TeacherId != CurrentUserId && !User.IsInRole("Admin"))
            {
                return Forbid();
            }

            NewTask.CourseId = id;
            NewTask.CreatedAt = DateTime.Now;
            _context.CourseTasks.Add(NewTask);
            await _context.SaveChangesAsync();

            await SyncNewTaskToStudentPlansAsync(id, NewTask);

            return RedirectToPage(new { id });
        }

        public async Task<IActionResult> OnPostDeleteTaskAsync(int id, int taskId)
        {
            var task = await _context.CourseTasks.Include(t => t.Course).FirstOrDefaultAsync(t => t.TaskId == taskId);
            if (task == null) return RedirectToPage(new { id });

            if (task.CourseId != id)
            {
                return Forbid();
            }
            if (task.Course?.TeacherId != CurrentUserId && !User.IsInRole("Admin"))
            {
                return Forbid();
            }

            var planTasks = await _context.PlanTasks
                .Include(pt => pt.StudyPlan)
                .Where(pt => pt.TaskId == taskId)
                .ToListAsync();

            var affectedStudents = planTasks
                .Where(pt => pt.StudyPlan != null)
                .Select(pt => pt.StudyPlan!.StudentId)
                .Distinct()
                .ToList();

            _context.PlanTasks.RemoveRange(planTasks);
            _context.CourseTasks.Remove(task);
            await _context.SaveChangesAsync();

            if (affectedStudents.Count > 0)
            {
                await NotifyStudentsAsync(affectedStudents, $"课程《{task.Course?.CourseName}》的任务「{task.TaskName}」已被教师删除，计划已同步更新。");
            }

            return RedirectToPage(new { id });
        }

        public async Task<IActionResult> OnPostUpdateTaskAsync(int id, int taskId, string taskName, string? description, int estimatedHours, string? resourceUrl)
        {
            var task = await _context.CourseTasks.Include(t => t.Course).FirstOrDefaultAsync(t => t.TaskId == taskId);
            if (task == null) return RedirectToPage(new { id });

            if (task.CourseId != id)
            {
                return Forbid();
            }
            if (task.Course?.TeacherId != CurrentUserId && !User.IsInRole("Admin"))
            {
                return Forbid();
            }

            taskName = taskName?.Trim() ?? string.Empty;
            description = string.IsNullOrWhiteSpace(description) ? null : description.Trim();
            resourceUrl = ResourceUrlHelper.NormalizeForStorage(resourceUrl);
            if (estimatedHours < 1) estimatedHours = 1;

            task.TaskName = taskName;
            task.Description = description;
            task.EstimatedHours = estimatedHours;
            task.ResourceUrl = resourceUrl;

            await _context.SaveChangesAsync();

            var affectedStudents = await _context.PlanTasks
                .Include(pt => pt.StudyPlan)
                .Where(pt => pt.TaskId == taskId && pt.StudyPlan != null)
                .Select(pt => pt.StudyPlan!.StudentId)
                .Distinct()
                .ToListAsync();

            if (affectedStudents.Count > 0)
            {
                await NotifyStudentsAsync(affectedStudents, $"课程《{task.Course?.CourseName}》的任务「{task.TaskName}」已被教师修改，请查看最新要求。");
            }

            return RedirectToPage(new { id });
        }

        private async Task<IActionResult> LoadCourse(int id)
        {
            var course = await _context.Courses
                .Include(c => c.Teacher)
                .Include(c => c.Tasks)
                .FirstOrDefaultAsync(c => c.CourseId == id);

            if (course == null)
            {
                return NotFound();
            }

            if (course.TeacherId != CurrentUserId && !User.IsInRole("Admin"))
            {
                return Forbid();
            }

            Course = course;
            return Page();
        }

        private async Task SyncNewTaskToStudentPlansAsync(int courseId, CourseTask task)
        {
            var plans = await _context.StudyPlans
                .Include(p => p.PlanTasks)
                .Where(p => p.CourseId == courseId)
                .ToListAsync();

            foreach (var plan in plans)
            {
                if (plan.PlanTasks.Any(pt => pt.TaskId == task.TaskId)) continue;

                _context.PlanTasks.Add(new PlanTask
                {
                    PlanId = plan.PlanId,
                    TaskId = task.TaskId,
                    PlannedDate = plan.EndDate,
                    IsCompleted = false
                });
            }

            await _context.SaveChangesAsync();

            var students = plans.Select(p => p.StudentId).Distinct().ToList();
            if (students.Count > 0)
            {
                var courseName = await _context.Courses.Where(c => c.CourseId == courseId).Select(c => c.CourseName).FirstOrDefaultAsync();
                await NotifyStudentsAsync(students, $"课程《{courseName}》新增任务「{task.TaskName}」，已同步到您的学习计划。");
            }
        }

        private async Task NotifyStudentsAsync(IEnumerable<int> studentIds, string content)
        {
            var receiverIds = studentIds.Distinct().ToList();
            if (receiverIds.Count == 0) return;

            var messages = receiverIds.Select(id => new Message
            {
                SenderId = CurrentUserId,
                ReceiverId = id,
                Subject = "课程公告",
                Content = content,
                Category = "Announcement",
                CreatedAt = DateTime.Now
            });

            _context.Messages.AddRange(messages);
            await _context.SaveChangesAsync();
        }
    }
}
