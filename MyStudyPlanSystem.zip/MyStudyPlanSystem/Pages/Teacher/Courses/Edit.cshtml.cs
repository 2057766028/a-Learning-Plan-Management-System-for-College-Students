using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MyStudyPlanSystem.Data;
using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using System.IO;
using System;

namespace MyStudyPlanSystem.Pages.Teacher.Courses
{
    [Authorize(Policy = "RequireTeacherRole")]
    public class EditModel : PageModel
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _environment;

        public EditModel(AppDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        [BindProperty]
        public CourseInput Input { get; set; } = new();

        [BindProperty]
        public IFormFile? MaterialFile { get; set; }

        [BindProperty]
        public bool RemoveMaterial { get; set; }

        [BindProperty]
        public int CourseId { get; set; }

        public string? ExistingMaterial { get; set; }

        public class CourseInput
        {
            [Required]
            [StringLength(30)]
            public string CourseCode { get; set; } = string.Empty;

            [Required]
            [StringLength(100)]
            public string CourseName { get; set; } = string.Empty;

            [StringLength(500)]
            public string? Description { get; set; }
        }

        private int CurrentUserId => int.TryParse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value, out var id) ? id : 0;

        public async Task<IActionResult> OnGetAsync(int id)
        {
            var course = await _context.Courses.FirstOrDefaultAsync(c => c.CourseId == id);
            if (course == null) return NotFound();
            if (course.TeacherId != CurrentUserId && !User.IsInRole("Admin")) return Forbid();

            CourseId = course.CourseId;
            ExistingMaterial = course.MaterialPath;
            Input = new CourseInput
            {
                CourseCode = course.CourseCode,
                CourseName = course.CourseName,
                Description = course.Description
            };

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                var existing = await _context.Courses.AsNoTracking().FirstOrDefaultAsync(c => c.CourseId == CourseId);
                ExistingMaterial = existing?.MaterialPath;
                return Page();
            }

            Input.CourseCode = Input.CourseCode.Trim();
            Input.CourseName = Input.CourseName.Trim();
            Input.Description = Input.Description?.Trim();

            var course = await _context.Courses.FirstOrDefaultAsync(c => c.CourseId == CourseId);
            if (course == null) return NotFound();
            if (course.TeacherId != CurrentUserId && !User.IsInRole("Admin")) return Forbid();

            var duplicate = await _context.Courses.AnyAsync(c => c.CourseId != CourseId && c.CourseCode == Input.CourseCode);
            if (duplicate)
            {
                ModelState.AddModelError("Input.CourseCode", "课程编号已存在");
                ExistingMaterial = course.MaterialPath;
                return Page();
            }

            course.CourseCode = Input.CourseCode;
            course.CourseName = Input.CourseName;
            course.Description = Input.Description;

            if (RemoveMaterial && !string.IsNullOrEmpty(course.MaterialPath))
            {
                DeleteFileIfExists(course.MaterialPath);
                course.MaterialPath = null;
            }

            if (MaterialFile != null && MaterialFile.Length > 0)
            {
                if (!string.IsNullOrEmpty(course.MaterialPath))
                {
                    DeleteFileIfExists(course.MaterialPath);
                }

                var uploadsRoot = Path.Combine(_environment.WebRootPath, "uploads", "courses");
                Directory.CreateDirectory(uploadsRoot);
                var ext = Path.GetExtension(MaterialFile.FileName);
                var fileName = $"{course.CourseCode}_{Guid.NewGuid()}{ext}";
                var savePath = Path.Combine(uploadsRoot, fileName);

                using var stream = System.IO.File.Create(savePath);
                await MaterialFile.CopyToAsync(stream);

                course.MaterialPath = $"/uploads/courses/{fileName}".Replace("\\", "/");
            }

            await _context.SaveChangesAsync();
            return RedirectToPage("Index");
        }

        private void DeleteFileIfExists(string relativePath)
        {
            var trimmed = relativePath.TrimStart('~').TrimStart('/');
            var fullPath = Path.Combine(_environment.WebRootPath, trimmed.Replace("/", Path.DirectorySeparatorChar.ToString()));
            if (System.IO.File.Exists(fullPath))
            {
                System.IO.File.Delete(fullPath);
            }
        }
    }
}
