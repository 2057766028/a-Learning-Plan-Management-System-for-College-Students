using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MyStudyPlanSystem.Data;
using MyStudyPlanSystem.Models;
using System.Security.Claims;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System;

namespace MyStudyPlanSystem.Pages.Teacher.Courses
{
    [Authorize(Policy = "RequireTeacherRole")]
    public class CreateModel : PageModel
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _environment;

        public CreateModel(AppDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public Course Course { get; set; } = default!;

        [BindProperty]
        public IFormFile? MaterialFile { get; set; }

        public async Task<IActionResult> OnPostAsync()
        {
            // Navigation property不参与前端验证，避免必填阻塞
            ModelState.Remove("Course.Teacher");

            if (!ModelState.IsValid || _context.Courses == null || Course == null)
            {
                return Page();
            }

            var userIdStr = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!int.TryParse(userIdStr, out var teacherId))
            {
                return Forbid();
            }

            Course.CourseCode = Course.CourseCode.Trim();
            Course.CourseName = Course.CourseName.Trim();
            Course.Description = Course.Description?.Trim();

            if (await _context.Courses.AnyAsync(c => c.CourseCode == Course.CourseCode))
            {
                ModelState.AddModelError("Course.CourseCode", "课程编号已存在");
                return Page();
            }

            Course.TeacherId = teacherId;
            Course.CreatedAt = DateTime.Now;

            if (MaterialFile != null && MaterialFile.Length > 0)
            {
                var uploadsRoot = Path.Combine(_environment.WebRootPath, "uploads", "courses");
                Directory.CreateDirectory(uploadsRoot);

                var ext = Path.GetExtension(MaterialFile.FileName);
                var fileName = $"{Course.CourseCode}_{Guid.NewGuid()}{ext}";
                var savePath = Path.Combine(uploadsRoot, fileName);

                using var stream = System.IO.File.Create(savePath);
                await MaterialFile.CopyToAsync(stream);

                Course.MaterialPath = $"/uploads/courses/{fileName}".Replace("\\", "/");
            }

            _context.Courses.Add(Course);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
