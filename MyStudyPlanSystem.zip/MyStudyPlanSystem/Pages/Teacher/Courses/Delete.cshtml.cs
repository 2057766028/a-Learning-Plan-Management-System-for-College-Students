using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MyStudyPlanSystem.Data;
using MyStudyPlanSystem.Models;
using System.Security.Claims;
using Microsoft.AspNetCore.Hosting;
using System.IO;

namespace MyStudyPlanSystem.Pages.Teacher.Courses
{
    [Authorize(Policy = "RequireTeacherRole")]
    public class DeleteModel : PageModel
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _environment;

        public DeleteModel(AppDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        [BindProperty]
        public Course Course { get; set; } = default!;

        private int CurrentUserId => int.TryParse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value, out var id) ? id : 0;

        public async Task<IActionResult> OnGetAsync(int id)
        {
            var course = await _context.Courses.Include(c => c.Teacher).FirstOrDefaultAsync(m => m.CourseId == id);
            if (course == null)
            {
                return NotFound();
            }

            if (course.TeacherId != CurrentUserId && !User.IsInRole("Admin"))
            {
                return Forbid();
            }

            Course = course;
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int id)
        {
            var course = await _context.Courses.FindAsync(id);

            if (course != null)
            {
                if (course.TeacherId != CurrentUserId && !User.IsInRole("Admin"))
                {
                    return Forbid();
                }

                if (!string.IsNullOrEmpty(course.MaterialPath))
                {
                    DeleteFileIfExists(course.MaterialPath);
                }

                _context.Courses.Remove(course);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }

        private void DeleteFileIfExists(string relativePath)
        {
            var trimmed = relativePath.TrimStart('~').TrimStart('/');
            var fullPath = Path.Combine(_environment.WebRootPath, trimmed.Replace("/", Path.DirectorySeparatorChar.ToString()));
            if (System.IO.File.Exists(fullPath))
            {
                System.IO.File.Delete(fullPath);
            }
        }
    }
}
