using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MyStudyPlanSystem.Data;
using MyStudyPlanSystem.Models;
using System.Security.Claims;

namespace MyStudyPlanSystem.Pages.Teacher.Courses
{
    public class IndexModel : PageModel
    {
        private readonly AppDbContext _context;

        public IndexModel(AppDbContext context)
        {
            _context = context;
        }

        public IList<Course> Courses { get; set; } = default!;

        public async Task OnGetAsync()
        {
            var userIdStr = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var isTeacher = User.FindFirst(ClaimTypes.Role)?.Value == "Teacher";

            var query = _context.Courses
                .Include(c => c.Teacher)
                .Include(c => c.Tasks)
                .OrderByDescending(c => c.CreatedAt)
                .AsQueryable();

            if (isTeacher && int.TryParse(userIdStr, out var teacherId))
            {
                query = query.Where(c => c.TeacherId == teacherId);
            }

            Courses = await query.ToListAsync();
        }
    }
}
