﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MyStudyPlanSystem.Data;
using System.Security.Claims;
using System.Text.Json;

namespace MyStudyPlanSystem.Pages.Teacher.Reports
{
    [Authorize(Policy = "RequireTeacherRole")]
    public class IndexModel : PageModel
    {
        private static readonly JsonSerializerOptions JsonOptions = new()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        };

        private readonly AppDbContext _context;

        public IndexModel(AppDbContext context)
        {
            _context = context;
        }

        public IList<CourseSummaryViewModel> CourseSummaries { get; private set; } = new List<CourseSummaryViewModel>();
        public IList<StudentProgressViewModel> StudentProgressRows { get; private set; } = new List<StudentProgressViewModel>();
        public IList<TaskProgressViewModel> TaskProgressRows { get; private set; } = new List<TaskProgressViewModel>();
        public IList<ManagedCourseViewModel> ManagedCourses { get; private set; } = new List<ManagedCourseViewModel>();
        public IList<StudentAggregateViewModel> ManagedStudents { get; private set; } = new List<StudentAggregateViewModel>();
        public int ManagedCourseCount { get; private set; }
        public int ManagedStudentCount { get; private set; }
        public int TotalTaskCount { get; private set; }
        public int CompletedTaskCount { get; private set; }
        public int OverdueTaskCount { get; private set; }
        public int PendingTaskCount => Math.Max(0, TotalTaskCount - CompletedTaskCount);
        public double CompletionRate => TotalTaskCount == 0 ? 0 : Math.Round(CompletedTaskCount * 100d / TotalTaskCount, 1);
        public string DetailPayloadJson { get; private set; } = "{}";
        public string OverallChartJson => JsonSerializer.Serialize(new
        {
            completed = CompletedTaskCount,
            pending = PendingTaskCount
        }, JsonOptions);

        public async Task OnGetAsync()
        {
            var teacherId = GetCurrentUserId();
            if (teacherId <= 0)
            {
                return;
            }

            var teacherCourses = await _context.Courses
                .Where(c => c.TeacherId == teacherId)
                .OrderByDescending(c => c.CreatedAt)
                .Select(c => new TeacherCourseViewModel
                {
                    CourseId = c.CourseId,
                    CourseCode = c.CourseCode,
                    CourseName = c.CourseName,
                    CreatedAt = c.CreatedAt,
                    TaskTemplateCount = c.Tasks.Count
                })
                .ToListAsync();

            ManagedCourseCount = teacherCourses.Count;
            if (teacherCourses.Count == 0)
            {
                DetailPayloadJson = JsonSerializer.Serialize(new ReportPayload(), JsonOptions);
                return;
            }

            var courseIds = teacherCourses.Select(c => c.CourseId).ToList();
            var today = DateTime.Today;

            var plans = await _context.StudyPlans
                .Where(p => p.CourseId.HasValue && courseIds.Contains(p.CourseId.Value))
                .Include(p => p.Student)
                .Include(p => p.Course)
                .Include(p => p.PlanTasks)
                    .ThenInclude(t => t.CourseTask)
                .ToListAsync();

            TaskProgressRows = plans
                .SelectMany(plan => plan.PlanTasks.Select(task => new TaskProgressViewModel
                {
                    CourseId = plan.CourseId!.Value,
                    CourseCode = plan.Course?.CourseCode ?? string.Empty,
                    CourseName = plan.Course?.CourseName ?? "未命名课程",
                    StudentId = plan.StudentId,
                    StudentNumber = plan.Student?.Username ?? string.Empty,
                    StudentName = plan.Student?.RealName ?? "未知学生",
                    TaskId = task.TaskId,
                    TaskName = task.CourseTask?.TaskName ?? $"任务 {task.TaskId}",
                    PlannedDate = task.PlannedDate,
                    CompletedDate = task.CompletedDate,
                    IsCompleted = task.IsCompleted,
                    Notes = task.Notes
                }))
                .OrderBy(row => row.CourseName)
                .ThenBy(row => row.StudentName)
                .ThenBy(row => row.PlannedDate)
                .ToList();

            StudentProgressRows = plans
                .GroupBy(p => new { CourseId = p.CourseId!.Value, p.StudentId })
                .Select(group =>
                {
                    var firstPlan = group.First();
                    var tasks = group.SelectMany(p => p.PlanTasks).ToList();
                    var completedTasks = tasks.Count(t => t.IsCompleted);
                    var overdueTasks = tasks.Count(t => !t.IsCompleted && t.PlannedDate.Date < today);

                    return new StudentProgressViewModel
                    {
                        CourseId = firstPlan.CourseId!.Value,
                        CourseCode = firstPlan.Course?.CourseCode ?? string.Empty,
                        CourseName = firstPlan.Course?.CourseName ?? "未命名课程",
                        StudentId = firstPlan.StudentId,
                        StudentNumber = firstPlan.Student?.Username ?? string.Empty,
                        StudentName = firstPlan.Student?.RealName ?? "未知学生",
                        Major = firstPlan.Student?.Major,
                        Grade = firstPlan.Student?.Grade,
                        ClassName = firstPlan.Student?.ClassName,
                        TotalTasks = tasks.Count,
                        CompletedTasks = completedTasks,
                        OverdueTasks = overdueTasks
                    };
                })
                .OrderBy(row => row.CourseName)
                .ThenBy(row => row.StudentName)
                .ToList();

            ManagedStudents = StudentProgressRows
                .GroupBy(row => row.StudentId)
                .Select(group =>
                {
                    var first = group.First();
                    return new StudentAggregateViewModel
                    {
                        StudentId = first.StudentId,
                        StudentNumber = first.StudentNumber,
                        StudentName = first.StudentName,
                        Major = first.Major,
                        Grade = first.Grade,
                        ClassName = first.ClassName,
                        CourseCount = group.Select(row => row.CourseId).Distinct().Count(),
                        TotalTasks = group.Sum(row => row.TotalTasks),
                        CompletedTasks = group.Sum(row => row.CompletedTasks),
                        OverdueTasks = group.Sum(row => row.OverdueTasks)
                    };
                })
                .OrderBy(student => student.StudentName)
                .ToList();

            ManagedStudentCount = ManagedStudents.Count;
            TotalTaskCount = StudentProgressRows.Sum(row => row.TotalTasks);
            CompletedTaskCount = StudentProgressRows.Sum(row => row.CompletedTasks);
            OverdueTaskCount = StudentProgressRows.Sum(row => row.OverdueTasks);

            var summaryLookup = StudentProgressRows
                .GroupBy(row => row.CourseId)
                .ToDictionary(
                    group => group.Key,
                    group => new CourseSummaryViewModel
                    {
                        CourseId = group.Key,
                        CourseCode = group.First().CourseCode,
                        CourseName = group.First().CourseName,
                        StudentCount = group.Select(row => row.StudentId).Distinct().Count(),
                        TotalTasks = group.Sum(row => row.TotalTasks),
                        CompletedTasks = group.Sum(row => row.CompletedTasks),
                        OverdueTasks = group.Sum(row => row.OverdueTasks)
                    });

            CourseSummaries = teacherCourses
                .Select(course => summaryLookup.TryGetValue(course.CourseId, out var summary)
                    ? summary
                    : new CourseSummaryViewModel
                    {
                        CourseId = course.CourseId,
                        CourseCode = course.CourseCode,
                        CourseName = course.CourseName,
                        StudentCount = 0,
                        TotalTasks = 0,
                        CompletedTasks = 0,
                        OverdueTasks = 0
                    })
                .ToList();

            ManagedCourses = teacherCourses
                .Select(course =>
                {
                    summaryLookup.TryGetValue(course.CourseId, out var summary);
                    return new ManagedCourseViewModel
                    {
                        CourseId = course.CourseId,
                        CourseCode = course.CourseCode,
                        CourseName = course.CourseName,
                        CreatedAt = course.CreatedAt,
                        TaskTemplateCount = course.TaskTemplateCount,
                        StudentCount = summary?.StudentCount ?? 0,
                        TotalTasks = summary?.TotalTasks ?? 0,
                        CompletedTasks = summary?.CompletedTasks ?? 0,
                        OverdueTasks = summary?.OverdueTasks ?? 0
                    };
                })
                .ToList();

            DetailPayloadJson = JsonSerializer.Serialize(BuildPayload(), JsonOptions);
        }

        private ReportPayload BuildPayload()
        {
            var completedTaskRows = TaskProgressRows
                .Where(row => row.IsCompleted)
                .OrderByDescending(row => row.CompletedDate ?? DateTime.MinValue)
                .ThenBy(row => row.StudentName)
                .ThenBy(row => row.CourseName)
                .ToList();

            var overdueTaskRows = TaskProgressRows
                .Where(row => row.IsOverdue)
                .OrderByDescending(row => row.OverdueDays)
                .ThenBy(row => row.StudentName)
                .ThenBy(row => row.CourseName)
                .ThenBy(row => row.PlannedDate)
                .ToList();

            var courseDetails = CourseSummaries
                .Select(course => new CourseDetailViewModel
                {
                    CourseId = course.CourseId,
                    CourseCode = course.CourseCode,
                    CourseName = course.CourseName,
                    StudentCount = course.StudentCount,
                    TotalTasks = course.TotalTasks,
                    CompletedTasks = course.CompletedTasks,
                    OverdueTasks = course.OverdueTasks,
                    Students = StudentProgressRows
                        .Where(row => row.CourseId == course.CourseId)
                        .OrderBy(row => row.StudentName)
                        .ToList()
                })
                .ToList();

            var studentDetails = ManagedStudents
                .Select(student => new StudentDetailViewModel
                {
                    StudentId = student.StudentId,
                    StudentNumber = student.StudentNumber,
                    StudentName = student.StudentName,
                    Major = student.Major,
                    Grade = student.Grade,
                    ClassName = student.ClassName,
                    CourseCount = student.CourseCount,
                    TotalTasks = student.TotalTasks,
                    CompletedTasks = student.CompletedTasks,
                    OverdueTasks = student.OverdueTasks,
                    Courses = StudentProgressRows
                        .Where(row => row.StudentId == student.StudentId)
                        .OrderBy(row => row.CourseName)
                        .ToList()
                })
                .ToList();

            return new ReportPayload
            {
                ManagedCourses = ManagedCourses.ToList(),
                ManagedStudents = ManagedStudents.ToList(),
                AllTaskRows = TaskProgressRows.ToList(),
                CompletedTaskRows = completedTaskRows,
                OverdueTaskRows = overdueTaskRows,
                CourseDetails = courseDetails,
                StudentDetails = studentDetails
            };
        }

        private int GetCurrentUserId()
        {
            return int.TryParse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value, out var id) ? id : 0;
        }

        public class CourseSummaryViewModel
        {
            public int CourseId { get; set; }
            public string CourseCode { get; set; } = string.Empty;
            public string CourseName { get; set; } = string.Empty;
            public int StudentCount { get; set; }
            public int TotalTasks { get; set; }
            public int CompletedTasks { get; set; }
            public int OverdueTasks { get; set; }
            public int PendingTasks => Math.Max(0, TotalTasks - CompletedTasks);
            public double CompletionRate => TotalTasks == 0 ? 0 : Math.Round(CompletedTasks * 100d / TotalTasks, 1);
        }

        public class StudentProgressViewModel
        {
            public int CourseId { get; set; }
            public string CourseCode { get; set; } = string.Empty;
            public string CourseName { get; set; } = string.Empty;
            public int StudentId { get; set; }
            public string StudentNumber { get; set; } = string.Empty;
            public string StudentName { get; set; } = string.Empty;
            public string? Major { get; set; }
            public string? Grade { get; set; }
            public string? ClassName { get; set; }
            public int TotalTasks { get; set; }
            public int CompletedTasks { get; set; }
            public int OverdueTasks { get; set; }
            public int PendingTasks => Math.Max(0, TotalTasks - CompletedTasks);
            public double CompletionRate => TotalTasks == 0 ? 0 : Math.Round(CompletedTasks * 100d / TotalTasks, 1);
        }

        public class TaskProgressViewModel
        {
            public int CourseId { get; set; }
            public string CourseCode { get; set; } = string.Empty;
            public string CourseName { get; set; } = string.Empty;
            public int StudentId { get; set; }
            public string StudentNumber { get; set; } = string.Empty;
            public string StudentName { get; set; } = string.Empty;
            public int TaskId { get; set; }
            public string TaskName { get; set; } = string.Empty;
            public DateTime PlannedDate { get; set; }
            public DateTime? CompletedDate { get; set; }
            public bool IsCompleted { get; set; }
            public string? Notes { get; set; }
            public bool IsOverdue => !IsCompleted && PlannedDate.Date < DateTime.Today;
            public int OverdueDays => IsOverdue ? (DateTime.Today - PlannedDate.Date).Days : 0;
        }

        public class ManagedCourseViewModel
        {
            public int CourseId { get; set; }
            public string CourseCode { get; set; } = string.Empty;
            public string CourseName { get; set; } = string.Empty;
            public DateTime CreatedAt { get; set; }
            public int TaskTemplateCount { get; set; }
            public int StudentCount { get; set; }
            public int TotalTasks { get; set; }
            public int CompletedTasks { get; set; }
            public int OverdueTasks { get; set; }
            public int PendingTasks => Math.Max(0, TotalTasks - CompletedTasks);
            public double CompletionRate => TotalTasks == 0 ? 0 : Math.Round(CompletedTasks * 100d / TotalTasks, 1);
        }

        public class StudentAggregateViewModel
        {
            public int StudentId { get; set; }
            public string StudentNumber { get; set; } = string.Empty;
            public string StudentName { get; set; } = string.Empty;
            public string? Major { get; set; }
            public string? Grade { get; set; }
            public string? ClassName { get; set; }
            public int CourseCount { get; set; }
            public int TotalTasks { get; set; }
            public int CompletedTasks { get; set; }
            public int OverdueTasks { get; set; }
            public int PendingTasks => Math.Max(0, TotalTasks - CompletedTasks);
            public double CompletionRate => TotalTasks == 0 ? 0 : Math.Round(CompletedTasks * 100d / TotalTasks, 1);
        }

        public class CourseDetailViewModel
        {
            public int CourseId { get; set; }
            public string CourseCode { get; set; } = string.Empty;
            public string CourseName { get; set; } = string.Empty;
            public int StudentCount { get; set; }
            public int TotalTasks { get; set; }
            public int CompletedTasks { get; set; }
            public int OverdueTasks { get; set; }
            public int PendingTasks => Math.Max(0, TotalTasks - CompletedTasks);
            public double CompletionRate => TotalTasks == 0 ? 0 : Math.Round(CompletedTasks * 100d / TotalTasks, 1);
            public IList<StudentProgressViewModel> Students { get; set; } = new List<StudentProgressViewModel>();
        }

        public class StudentDetailViewModel
        {
            public int StudentId { get; set; }
            public string StudentNumber { get; set; } = string.Empty;
            public string StudentName { get; set; } = string.Empty;
            public string? Major { get; set; }
            public string? Grade { get; set; }
            public string? ClassName { get; set; }
            public int CourseCount { get; set; }
            public int TotalTasks { get; set; }
            public int CompletedTasks { get; set; }
            public int OverdueTasks { get; set; }
            public int PendingTasks => Math.Max(0, TotalTasks - CompletedTasks);
            public double CompletionRate => TotalTasks == 0 ? 0 : Math.Round(CompletedTasks * 100d / TotalTasks, 1);
            public IList<StudentProgressViewModel> Courses { get; set; } = new List<StudentProgressViewModel>();
        }

        public class ReportPayload
        {
            public IList<ManagedCourseViewModel> ManagedCourses { get; set; } = new List<ManagedCourseViewModel>();
            public IList<StudentAggregateViewModel> ManagedStudents { get; set; } = new List<StudentAggregateViewModel>();
            public IList<TaskProgressViewModel> AllTaskRows { get; set; } = new List<TaskProgressViewModel>();
            public IList<TaskProgressViewModel> CompletedTaskRows { get; set; } = new List<TaskProgressViewModel>();
            public IList<TaskProgressViewModel> OverdueTaskRows { get; set; } = new List<TaskProgressViewModel>();
            public IList<CourseDetailViewModel> CourseDetails { get; set; } = new List<CourseDetailViewModel>();
            public IList<StudentDetailViewModel> StudentDetails { get; set; } = new List<StudentDetailViewModel>();
        }

        private class TeacherCourseViewModel
        {
            public int CourseId { get; set; }
            public string CourseCode { get; set; } = string.Empty;
            public string CourseName { get; set; } = string.Empty;
            public DateTime CreatedAt { get; set; }
            public int TaskTemplateCount { get; set; }
        }
    }
}
