using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MyStudyPlanSystem.Data;
using MyStudyPlanSystem.Models;
using System.Security.Claims;
using System.Linq;

namespace MyStudyPlanSystem.Pages.Messages
{
    [Authorize]
    public class IndexModel : PageModel
    {
        private readonly AppDbContext _context;

        public IndexModel(AppDbContext context)
        {
            _context = context;
        }

        public IList<Message> ReceivedMessages { get; set; } = new List<Message>();
        public IList<Message> SentMessages { get; set; } = new List<Message>();
        public IList<User> Receivers { get; set; } = new List<User>();

        public string CurrentRole => User.FindFirst(ClaimTypes.Role)?.Value ?? string.Empty;

        public int CurrentUserId => int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");

        public async Task OnGetAsync()
        {
            await LoadMessagesAsync(true);
        }

        private IEnumerable<string> AllowedReceiverRoles()
        {
            return CurrentRole switch
            {
                "Student" => new[] { "Teacher", "Student", "Admin" },
                "Teacher" => new[] { "Student", "Admin", "Teacher" },
                "Admin" => new[] { "Teacher", "Student", "Admin" },
                _ => Array.Empty<string>()
            };
        }

        private async Task LoadMessagesAsync(bool markAsRead)
        {
            var userId = CurrentUserId;

            ReceivedMessages = await _context.Messages
                .Include(m => m.Sender)
                .Include(m => m.Receiver)
                .Include(m => m.Replies)
                    .ThenInclude(r => r.Sender)
                .Where(m => m.ReceiverId == userId)
                .OrderByDescending(m => m.CreatedAt)
                .ToListAsync();

            SentMessages = await _context.Messages
                .Include(m => m.Receiver)
                .Include(m => m.Sender)
                .Include(m => m.Replies)
                    .ThenInclude(r => r.Sender)
                .Where(m => m.SenderId == userId)
                .OrderByDescending(m => m.CreatedAt)
                .ToListAsync();

            var legacyReplies = ReceivedMessages
                .Concat(SentMessages)
                .Where(m => !string.IsNullOrWhiteSpace(m.Reply) && !m.Replies.Any())
                .ToList();

            if (legacyReplies.Count > 0)
            {
                foreach (var msg in legacyReplies)
                {
                    _context.MessageReplies.Add(new MessageReply
                    {
                        MessageId = msg.MessageId,
                        SenderId = msg.ReceiverId,
                        Content = msg.Reply!,
                        CreatedAt = msg.RepliedAt ?? msg.CreatedAt
                    });
                    msg.Reply = null;
                }
                await _context.SaveChangesAsync();
            }

            if (markAsRead)
            {
                var unread = ReceivedMessages.Where(m => !m.IsRead).ToList();
                if (unread.Count > 0)
                {
                    foreach (var msg in unread)
                    {
                        msg.IsRead = true;
                    }
                    await _context.SaveChangesAsync();
                }
            }

            var allowedRoles = AllowedReceiverRoles().ToList();
            Receivers = await _context.Users
                .Where(u => allowedRoles.Contains(u.Role) && u.UserId != userId)
                .OrderBy(u => u.RealName)
                .ToListAsync();
        }

        public async Task<IActionResult> OnPostSendAsync(string ReceiverUsername, string Content)
        {
            await LoadMessagesAsync(false);

            if (string.IsNullOrWhiteSpace(ReceiverUsername) || string.IsNullOrWhiteSpace(Content))
            {
                ModelState.AddModelError(string.Empty, "请输入收件人账号和消息内容。");
                return Page();
            }

            var receiver = await _context.Users.FirstOrDefaultAsync(u => u.Username == ReceiverUsername);
            if (receiver == null)
            {
                ModelState.AddModelError(string.Empty, "未找到该收件人，请确认账号。");
                return Page();
            }

            if (receiver.UserId == CurrentUserId)
            {
                ModelState.AddModelError(string.Empty, "不能给自己发送消息。");
                return Page();
            }

            var allowedRoles = AllowedReceiverRoles();
            if (!allowedRoles.Contains(receiver.Role))
            {
                ModelState.AddModelError(string.Empty, "当前角色无权向该类型用户发送消息。");
                return Page();
            }

            var subject = Content.Trim();
            if (subject.Length > 20)
            {
                subject = $"{subject.Substring(0, 20)}...";
            }

            var msg = new Message
            {
                Subject = string.IsNullOrWhiteSpace(subject) ? "消息" : subject,
                Content = Content.Trim(),
                SenderId = CurrentUserId,
                ReceiverId = receiver.UserId,
                CreatedAt = DateTime.Now,
                Category = "General"
            };

            _context.Messages.Add(msg);
            await _context.SaveChangesAsync();

            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostReplyAsync(int MessageId, string ReplyContent)
        {
            await LoadMessagesAsync(false);

            if (string.IsNullOrWhiteSpace(ReplyContent))
            {
                ModelState.AddModelError(string.Empty, "请输入回复内容。");
                return Page();
            }

            var msg = await _context.Messages.FindAsync(MessageId);
            if (msg == null || !(msg.ReceiverId == CurrentUserId || msg.SenderId == CurrentUserId))
            {
                ModelState.AddModelError(string.Empty, "消息不存在或无权限回复。");
                return Page();
            }

            if (string.Equals(msg.Category, "Announcement", StringComparison.OrdinalIgnoreCase))
            {
                ModelState.AddModelError(string.Empty, "系统公告无法回复。");
                return Page();
            }

            _context.MessageReplies.Add(new MessageReply
            {
                MessageId = MessageId,
                SenderId = CurrentUserId,
                Content = ReplyContent.Trim(),
                CreatedAt = DateTime.Now
            });
            msg.RepliedAt = DateTime.Now;
            msg.IsRead = false;
            await _context.SaveChangesAsync();

            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostDeleteReceivedAsync(int id)
        {
            await LoadMessagesAsync(false);
            var msg = await _context.Messages.FirstOrDefaultAsync(m => m.MessageId == id && m.ReceiverId == CurrentUserId);
            if (msg != null)
            {
                _context.Messages.Remove(msg);
                await _context.SaveChangesAsync();
            }
            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostDeleteSentAsync(int id)
        {
            await LoadMessagesAsync(false);
            var msg = await _context.Messages.FirstOrDefaultAsync(m => m.MessageId == id && m.SenderId == CurrentUserId);
            if (msg != null)
            {
                _context.Messages.Remove(msg);
                await _context.SaveChangesAsync();
            }
            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostDeleteAllReceivedAsync()
        {
            var userId = CurrentUserId;
            if (userId <= 0) return Unauthorized();

            await _context.Messages
                .Where(m => m.ReceiverId == userId)
                .ExecuteDeleteAsync();

            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostDeleteAllSentAsync()
        {
            var userId = CurrentUserId;
            if (userId <= 0) return Unauthorized();

            await _context.Messages
                .Where(m => m.SenderId == userId)
                .ExecuteDeleteAsync();

            return RedirectToPage();
        }
    }
}
