using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MyStudyPlanSystem.Data;
using MyStudyPlanSystem.Models;
using System.Text.Json;

namespace MyStudyPlanSystem.Pages.Student.Plan
{
    public class IndexModel : PageModel
    {
        private readonly AppDbContext _context;

        public IndexModel(AppDbContext context)
        {
            _context = context;
        }

        public IList<StudyPlan> Plans { get; set; } = default!;
        public IList<PlanTask> TodayTasks { get; set; } = new List<PlanTask>();
        public int TotalTasks { get; set; }
        public int CompletedTasks { get; set; }
        public int TodayPendingCount { get; set; }
        public int PendingTasks => Math.Max(0, TotalTasks - CompletedTasks);
        public int OverduePending { get; set; }
        public int OverdueCompleted { get; set; }
        public List<PlanProgressDto> PlanProgress { get; set; } = new();
        public string PlanProgressJson => JsonSerializer.Serialize(PlanProgress);
        public string OverallChartJson => JsonSerializer.Serialize(new { completed = CompletedTasks, pending = PendingTasks });
        public string OverdueChartJson => JsonSerializer.Serialize(new
        {
            overduePending = OverduePending,
            overdueCompleted = OverdueCompleted,
            onTimeCompleted = Math.Max(0, CompletedTasks - OverdueCompleted)
        });

        public async Task OnGetAsync()
        {
            var userIdStr = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdStr)) return;

            var userId = int.Parse(userIdStr);

            Plans = await _context.StudyPlans
                .Where(p => p.StudentId == userId)
                .Include(p => p.PlanTasks)
                .ThenInclude(t => t.CourseTask)
                .ToListAsync();

            var today = DateTime.Today;
            TodayTasks = Plans
                .SelectMany(p => p.PlanTasks)
                .Where(t => t.PlannedDate.Date <= today && !t.IsCompleted)
                .OrderBy(t => t.PlannedDate)
                .ThenBy(t => t.PlanTaskId)
                .ToList();

            TotalTasks = Plans.Sum(p => p.PlanTasks.Count);
            CompletedTasks = Plans.Sum(p => p.PlanTasks.Count(t => t.IsCompleted));
            TodayPendingCount = TodayTasks.Count;
            OverduePending = Plans.SelectMany(p => p.PlanTasks).Count(t => !t.IsCompleted && t.PlannedDate.Date < today);
            OverdueCompleted = Plans.SelectMany(p => p.PlanTasks)
                .Count(t => t.IsCompleted && t.CompletedDate.HasValue && t.CompletedDate.Value.Date > t.PlannedDate.Date);

            PlanProgress = Plans.Select(p => new PlanProgressDto
            {
                PlanName = p.PlanName,
                Completed = p.PlanTasks.Count(t => t.IsCompleted),
                Total = p.PlanTasks.Count
            }).ToList();
        }

        public async Task<IActionResult> OnPostToggleAsync(int id, bool completed)
        {
            var userIdStr = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            _ = int.TryParse(userIdStr, out var userId);

            var task = await _context.PlanTasks
                .Include(pt => pt.StudyPlan)
                .FirstOrDefaultAsync(pt => pt.PlanTaskId == id);

            if (task != null && task.StudyPlan?.StudentId == userId)
            {
                task.IsCompleted = completed;
                task.CompletedDate = completed ? DateTime.Now : null;
                await _context.SaveChangesAsync();
            }

            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostCompleteTodayAsync()
        {
            var userIdStr = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (!int.TryParse(userIdStr, out var userId))
            {
                return RedirectToPage();
            }

            var today = DateTime.Today;
            var tasks = await _context.PlanTasks
                .Include(pt => pt.StudyPlan)
                .Where(pt => pt.StudyPlan != null && pt.StudyPlan.StudentId == userId && pt.PlannedDate.Date <= today && !pt.IsCompleted)
                .ToListAsync();

            foreach (var task in tasks)
            {
                task.IsCompleted = true;
                task.CompletedDate = DateTime.Now;
            }

            if (tasks.Count > 0)
            {
                await _context.SaveChangesAsync();
            }

            return RedirectToPage();
        }
        public async Task<IActionResult> OnPostDeletePlanAsync(int id)
        {
            var userIdStr = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (!int.TryParse(userIdStr, out var userId))
            {
                return RedirectToPage();
            }

            var plan = await _context.StudyPlans
                .Include(p => p.PlanTasks)
                .FirstOrDefaultAsync(p => p.PlanId == id && p.StudentId == userId);

            if (plan == null)
            {
                return RedirectToPage();
            }

            if (plan.PlanTasks.Count > 0)
            {
                _context.PlanTasks.RemoveRange(plan.PlanTasks);
            }

            _context.StudyPlans.Remove(plan);
            await _context.SaveChangesAsync();

            return RedirectToPage();
        }
        public class PlanProgressDto
        {
            public string PlanName { get; set; } = string.Empty;
            public int Completed { get; set; }
            public int Total { get; set; }
        }
    }
}
