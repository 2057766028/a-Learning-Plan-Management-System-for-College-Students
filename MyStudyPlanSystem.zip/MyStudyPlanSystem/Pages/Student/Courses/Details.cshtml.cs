using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MyStudyPlanSystem.Data;
using MyStudyPlanSystem.Models;

namespace MyStudyPlanSystem.Pages.Student.Courses
{
    public class DetailsModel : PageModel
    {
        private readonly AppDbContext _context;

        public DetailsModel(AppDbContext context)
        {
            _context = context;
        }

        public Course Course { get; set; } = default!;

        [BindProperty]
        public List<int> SelectedTaskIds { get; set; } = new();

        [BindProperty]
        public string PlanName { get; set; } = string.Empty;

        [BindProperty]
        public DateTime StartDate { get; set; } = DateTime.Today;

        [BindProperty]
        public DateTime EndDate { get; set; } = DateTime.Today.AddDays(7);

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.Courses == null)
            {
                return NotFound();
            }

            var course = await _context.Courses
                .Include(c => c.Teacher)
                .Include(c => c.Tasks)
                .FirstOrDefaultAsync(m => m.CourseId == id);

            if (course == null)
            {
                return NotFound();
            }

            Course = course;
            PlanName = $"学习计划: {Course.CourseName}";
            StartDate = DateTime.Today;
            EndDate = DateTime.Today.AddDays(7);
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? CourseId)
        {
            if (CourseId == null)
            {
                return NotFound();
            }

            var course = await _context.Courses
                .Include(c => c.Tasks)
                .FirstOrDefaultAsync(c => c.CourseId == CourseId);
            if (course == null)
            {
                return NotFound();
            }

            Course = course;

            var userIdStr = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdStr))
            {
                return RedirectToPage("/Index");
            }

            var userId = int.Parse(userIdStr);

            var alreadyPlanned = await _context.StudyPlans
                .AnyAsync(p => p.StudentId == userId && p.CourseId == course.CourseId);

            if (alreadyPlanned)
            {
                ModelState.AddModelError(string.Empty, "本课程已加入计划中，无需重复选择。");
                return Page();
            }

            var tasksToUse = SelectedTaskIds.Count > 0
                ? course.Tasks.Where(t => SelectedTaskIds.Contains(t.TaskId)).ToList()
                : course.Tasks.ToList();

            if (EndDate < StartDate)
            {
                EndDate = StartDate;
            }

            var planTitle = string.IsNullOrWhiteSpace(PlanName)
                ? $"学习计划: {course.CourseName}"
                : PlanName.Trim();

            var plan = new StudyPlan
            {
                StudentId = userId,
                CourseId = course.CourseId,
                PlanName = planTitle,
                Description = $"选取了 {tasksToUse.Count} 个任务生成计划",
                StartDate = StartDate,
                EndDate = EndDate,
                CreatedAt = DateTime.Now
            };

            _context.StudyPlans.Add(plan);
            await _context.SaveChangesAsync();

            var dayOffset = 0;
            foreach (var task in tasksToUse)
            {
                var plannedDate = StartDate.AddDays(dayOffset++);
                if (plannedDate > EndDate)
                {
                    plannedDate = EndDate;
                }

                _context.PlanTasks.Add(new PlanTask
                {
                    PlanId = plan.PlanId,
                    TaskId = task.TaskId,
                    PlannedDate = plannedDate,
                    IsCompleted = false
                });
            }

            await _context.SaveChangesAsync();
            return RedirectToPage("/Student/Plan/Index");
        }
    }
}
