using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MyStudyPlanSystem.Data;
using System.ComponentModel.DataAnnotations;

namespace MyStudyPlanSystem.Pages.Account
{
    [Authorize]
    public class ChangePasswordModel : PageModel
    {
        private readonly AppDbContext _context;

        public ChangePasswordModel(AppDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public InputModel Input { get; set; } = new();

        public class InputModel
        {
            [Required(ErrorMessage = "请输入当前密码")]
            public string CurrentPassword { get; set; } = string.Empty;

            [Required(ErrorMessage = "请输入新密码")]
            [StringLength(100, MinimumLength = 6, ErrorMessage = "新密码至少6位")]
            public string NewPassword { get; set; } = string.Empty;

            [Required(ErrorMessage = "请再次输入新密码")]
            [Compare("NewPassword", ErrorMessage = "两次输入的新密码不一致")]
            public string ConfirmPassword { get; set; } = string.Empty;
        }

        public void OnGet()
        {
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var userIdStr = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (!int.TryParse(userIdStr, out var userId))
            {
                return RedirectToPage("/Index");
            }

            var user = await _context.Users.FirstOrDefaultAsync(u => u.UserId == userId);
            if (user == null)
            {
                return RedirectToPage("/Index");
            }

            if (!string.Equals(user.Password, Input.CurrentPassword, StringComparison.Ordinal))
            {
                ModelState.AddModelError(string.Empty, "当前密码不正确");
                return Page();
            }

            user.Password = Input.NewPassword;
            await _context.SaveChangesAsync();

            TempData["PasswordChanged"] = "密码修改成功，请妥善保管。";
            return RedirectToPage();
        }
    }
}
