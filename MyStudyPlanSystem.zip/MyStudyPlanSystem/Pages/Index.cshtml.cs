using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MyStudyPlanSystem.Data;
using System.Security.Claims;

namespace MyStudyPlanSystem.Pages
{
    public class IndexModel : PageModel
    {
        private readonly AppDbContext _context;

        public IndexModel(AppDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public string Username { get; set; } = string.Empty;
        [BindProperty]
        public string Password { get; set; } = string.Empty;

        public async Task<IActionResult> OnGetAsync()
        {
            if (User?.Identity?.IsAuthenticated == true)
            {
                var role = User.FindFirst(ClaimTypes.Role)?.Value;
                if (role == "Teacher")
                {
                    return RedirectToPage("/Teacher/Courses/Index");
                }
                if (role == "Admin")
                {
                    return RedirectToPage("/Admin/Users/Index");
                }
                return RedirectToPage("/Student/Courses/Index");
            }

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.Username == Username && u.Password == Password);

            if (user != null)
            {
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, user.RealName),
                    new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
                    new Claim(ClaimTypes.Role, user.Role),
                    new Claim("Username", user.Username)
                };

                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                var authProperties = new AuthenticationProperties
                {
                    IsPersistent = true,
                    ExpiresUtc = DateTime.UtcNow.AddMinutes(60)
                };

                await HttpContext.SignInAsync(
                    CookieAuthenticationDefaults.AuthenticationScheme,
                    new ClaimsPrincipal(claimsIdentity),
                    authProperties);

                var unreadCount = await _context.Messages.CountAsync(m => m.ReceiverId == user.UserId && !m.IsRead);
                if (unreadCount > 0)
                {
                    TempData["LoginAlert"] = $"您有 {unreadCount} 条新消息，请及时查看。";
                }

                if (user.Role == "Teacher")
                {
                    return RedirectToPage("/Teacher/Courses/Index");
                }
                else if (user.Role == "Admin")
                {
                    return RedirectToPage("/Admin/Users/Index");
                }
                else
                {
                    return RedirectToPage("/Student/Courses/Index");
                }
            }

            ModelState.AddModelError(string.Empty, "用户名或密码错误");
            return Page();
        }
    }
}
