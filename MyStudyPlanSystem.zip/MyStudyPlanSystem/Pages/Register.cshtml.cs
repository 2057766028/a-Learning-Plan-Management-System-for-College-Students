using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MyStudyPlanSystem.Data;
using MyStudyPlanSystem.Models;
using System.ComponentModel.DataAnnotations;

namespace MyStudyPlanSystem.Pages
{
    public class RegisterModel : PageModel
    {
        private readonly AppDbContext _context;

        public RegisterModel(AppDbContext context)
        {
            _context = context;
        }

        public IList<MajorOption> Majors { get; set; } = new List<MajorOption>();
        public IList<GradeOption> Grades { get; set; } = new List<GradeOption>();
        public IList<ClassGroup> Classes { get; set; } = new List<ClassGroup>();

        [BindProperty]
        public InputModel Input { get; set; } = new();

        public class InputModel
        {
            [Required(ErrorMessage = "请输入学号")]
            [RegularExpression(@"^\d{8}$", ErrorMessage = "学号必须是 8 位数字")]
            public string StudentNumber { get; set; } = string.Empty;

            [Required(ErrorMessage = "请输入密码")]
            [StringLength(100, MinimumLength = 6, ErrorMessage = "密码长度至少 6 位")]
            public string Password { get; set; } = string.Empty;

            [Required(ErrorMessage = "请输入真实姓名")]
            [StringLength(50)]
            public string RealName { get; set; } = string.Empty;

            [Required(ErrorMessage = "请选择专业")]
            [StringLength(100)]
            public string Major { get; set; } = string.Empty;

            [Required(ErrorMessage = "请选择年级")]
            [StringLength(50)]
            public string Grade { get; set; } = string.Empty;

            [Required(ErrorMessage = "请选择班级")]
            [StringLength(50)]
            public string ClassName { get; set; } = string.Empty;
        }

        public async Task OnGetAsync()
        {
            await LoadOptionsAsync();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            Input.StudentNumber = NormalizeRequiredText(Input.StudentNumber);
            Input.Password = NormalizeRequiredText(Input.Password);
            Input.RealName = NormalizeRequiredText(Input.RealName);
            Input.Major = NormalizeSelection(Input.Major) ?? string.Empty;
            Input.Grade = NormalizeSelection(Input.Grade) ?? string.Empty;
            Input.ClassName = NormalizeSelection(Input.ClassName) ?? string.Empty;

            var majorLookup = await LoadNormalizedLookupAsync(_context.MajorOptions.Select(m => m.Name));
            var gradeLookup = await LoadNormalizedLookupAsync(_context.GradeOptions.Select(g => g.Name));
            var classLookup = await LoadNormalizedLookupAsync(_context.ClassGroups.Select(c => c.Name));

            ValidateSelection("Input.Major", "专业", Input.Major, majorLookup);
            ValidateSelection("Input.Grade", "年级", Input.Grade, gradeLookup);
            ValidateSelection("Input.ClassName", "班级", Input.ClassName, classLookup);

            if (await _context.Users.AnyAsync(u => u.Username == Input.StudentNumber))
            {
                ModelState.AddModelError("Input.StudentNumber", "该学号已被注册");
            }

            if (!ModelState.IsValid)
            {
                await LoadOptionsAsync();
                return Page();
            }

            var user = new User
            {
                Username = Input.StudentNumber,
                Password = Input.Password,
                RealName = Input.RealName,
                Role = "Student",
                Major = Input.Major,
                Grade = Input.Grade,
                ClassName = Input.ClassName,
                CreatedAt = DateTime.Now
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return RedirectToPage("/Index");
        }

        private async Task LoadOptionsAsync()
        {
            Majors = await _context.MajorOptions
                .OrderBy(m => m.Name)
                .ToListAsync();

            Grades = await _context.GradeOptions
                .OrderBy(g => g.Name)
                .ToListAsync();

            Classes = await _context.ClassGroups
                .OrderBy(c => c.Name)
                .ToListAsync();
        }

        private async Task<HashSet<string>> LoadNormalizedLookupAsync(IQueryable<string> query)
        {
            return (await query.ToListAsync())
                .Select(NormalizeSelection)
                .Where(value => !string.IsNullOrWhiteSpace(value))
                .Cast<string>()
                .ToHashSet(StringComparer.OrdinalIgnoreCase);
        }

        private void ValidateSelection(string fieldName, string displayName, string? value, HashSet<string> lookup)
        {
            if (lookup.Count == 0)
            {
                ModelState.AddModelError(string.Empty, $"当前尚未配置{displayName}，请联系管理员先添加{displayName}选项");
                return;
            }

            if (string.IsNullOrWhiteSpace(value))
            {
                return;
            }

            if (!lookup.Contains(value))
            {
                ModelState.AddModelError(fieldName, $"所选{displayName}不存在，请重新选择");
            }
        }

        private static string NormalizeRequiredText(string? value)
        {
            return value?.Trim() ?? string.Empty;
        }

        private static string? NormalizeSelection(string? value)
        {
            return string.IsNullOrWhiteSpace(value) ? null : value.Trim();
        }
    }
}
