using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MyStudyPlanSystem.Data;
using MyStudyPlanSystem.Models;
using System.Security.Claims;

namespace MyStudyPlanSystem.Pages.Admin.Settings
{
    [Authorize(Policy = "RequireAdminRole")]
    public class IndexModel : PageModel
    {
        private static readonly HashSet<string> ReservedClassNames = new(StringComparer.OrdinalIgnoreCase)
        {
            "管理员",
            "教师",
            "学生",
            "Admin",
            "Teacher",
            "Student"
        };

        private readonly AppDbContext _context;

        public IndexModel(AppDbContext context)
        {
            _context = context;
        }

        private int CurrentUserId => int.TryParse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value, out var id) ? id : 0;

        public IList<Term> Terms { get; set; } = new List<Term>();
        public IList<MajorOption> Majors { get; set; } = new List<MajorOption>();
        public IList<GradeOption> Grades { get; set; } = new List<GradeOption>();
        public IList<ClassGroup> Classes { get; set; } = new List<ClassGroup>();
        public IList<Announcement> Announcements { get; set; } = new List<Announcement>();
        public string ActiveTab { get; private set; } = "base-data";

        [BindProperty]
        public Term NewTerm { get; set; } = new()
        {
            Name = string.Empty,
            StartDate = DateTime.Today,
            EndDate = DateTime.Today.AddMonths(4)
        };

        [BindProperty]
        public MajorOption NewMajor { get; set; } = new()
        {
            Name = string.Empty
        };

        [BindProperty]
        public GradeOption NewGrade { get; set; } = new()
        {
            Name = string.Empty
        };

        [BindProperty]
        public ClassGroup NewClass { get; set; } = new()
        {
            Name = string.Empty
        };

        [BindProperty]
        public Announcement NewAnnouncement { get; set; } = new()
        {
            Title = string.Empty,
            Content = string.Empty
        };

        public async Task OnGetAsync()
        {
            await LoadAsync();
        }

        private async Task LoadAsync()
        {
            Terms = await _context.Terms
                .Include(t => t.Classes)
                .OrderByDescending(t => t.StartDate)
                .ToListAsync();

            Majors = await _context.MajorOptions
                .OrderBy(m => m.Name)
                .ToListAsync();

            Grades = await _context.GradeOptions
                .OrderBy(g => g.Name)
                .ToListAsync();

            Classes = await _context.ClassGroups
                .Include(c => c.Term)
                .Where(c => !ReservedClassNames.Contains(c.Name))
                .OrderBy(c => c.Name)
                .ToListAsync();

            Announcements = await _context.Announcements
                .OrderByDescending(a => a.CreatedAt)
                .ToListAsync();
        }

        public async Task<IActionResult> OnPostAddTermAsync()
        {
            NewTerm.Name = NormalizeName(NewTerm.Name);

            ModelState.Clear();
            var isValid = TryValidateModel(NewTerm, nameof(NewTerm));
            if (!isValid)
            {
                ActiveTab = "base-data";
                await LoadAsync();
                return Page();
            }

            _context.Terms.Add(NewTerm);
            await _context.SaveChangesAsync();
            SetStatusMessage("学期已保存。");
            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostAddMajorAsync()
        {
            NewMajor.Name = NormalizeName(NewMajor.Name);

            ModelState.Clear();
            var isValid = TryValidateModel(NewMajor, nameof(NewMajor));
            if (!isValid)
            {
                ActiveTab = "base-data";
                await LoadAsync();
                return Page();
            }

            if (await _context.MajorOptions.AnyAsync(m => m.Name == NewMajor.Name))
            {
                ModelState.AddModelError("NewMajor.Name", "该专业已存在。");
                ActiveTab = "base-data";
                await LoadAsync();
                return Page();
            }

            _context.MajorOptions.Add(NewMajor);
            await _context.SaveChangesAsync();
            SetStatusMessage("专业已保存。");
            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostAddGradeAsync()
        {
            NewGrade.Name = NormalizeName(NewGrade.Name);

            ModelState.Clear();
            var isValid = TryValidateModel(NewGrade, nameof(NewGrade));
            if (!isValid)
            {
                ActiveTab = "base-data";
                await LoadAsync();
                return Page();
            }

            if (await _context.GradeOptions.AnyAsync(g => g.Name == NewGrade.Name))
            {
                ModelState.AddModelError("NewGrade.Name", "该年级已存在。");
                ActiveTab = "base-data";
                await LoadAsync();
                return Page();
            }

            _context.GradeOptions.Add(NewGrade);
            await _context.SaveChangesAsync();
            SetStatusMessage("年级已保存。");
            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostAddClassAsync()
        {
            NewClass.Name = NormalizeName(NewClass.Name);

            ModelState.Clear();
            var isValid = TryValidateModel(NewClass, nameof(NewClass));
            if (!isValid)
            {
                ActiveTab = "class-management";
                await LoadAsync();
                return Page();
            }

            if (await _context.ClassGroups.AnyAsync(c => c.Name == NewClass.Name))
            {
                ModelState.AddModelError("NewClass.Name", "该班级已存在。");
                ActiveTab = "class-management";
                await LoadAsync();
                return Page();
            }

            if (ReservedClassNames.Contains(NewClass.Name))
            {
                ModelState.AddModelError("NewClass.Name", "该名称不能作为班级名称。");
                ActiveTab = "class-management";
                await LoadAsync();
                return Page();
            }

            _context.ClassGroups.Add(NewClass);
            await _context.SaveChangesAsync();
            SetStatusMessage("班级已保存。");
            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostAddAnnouncementAsync()
        {
            ModelState.Clear();
            var isValid = TryValidateModel(NewAnnouncement, nameof(NewAnnouncement));
            if (!isValid)
            {
                ActiveTab = "announcement-management";
                await LoadAsync();
                return Page();
            }

            NewAnnouncement.CreatedAt = DateTime.Now;
            _context.Announcements.Add(NewAnnouncement);
            await _context.SaveChangesAsync();
            await NotifyAllUsersAsync(NewAnnouncement.Title, NewAnnouncement.Content);
            SetStatusMessage("公告已发布。");
            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostToggleAnnouncementAsync(int id)
        {
            var announcement = await _context.Announcements.FindAsync(id);
            if (announcement != null)
            {
                announcement.IsActive = !announcement.IsActive;
                await _context.SaveChangesAsync();
                SetStatusMessage(announcement.IsActive ? "公告已重新发布。" : "公告已下线。");
            }

            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostDeleteTermAsync(int id)
        {
            var term = await _context.Terms.FindAsync(id);
            if (term != null)
            {
                _context.Terms.Remove(term);
                await _context.SaveChangesAsync();
                SetStatusMessage("学期已删除。", "warning");
            }

            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostDeleteMajorAsync(int id)
        {
            var major = await _context.MajorOptions.FindAsync(id);
            if (major != null)
            {
                _context.MajorOptions.Remove(major);
                await _context.SaveChangesAsync();
                SetStatusMessage("专业已删除。", "warning");
            }

            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostDeleteGradeAsync(int id)
        {
            var grade = await _context.GradeOptions.FindAsync(id);
            if (grade != null)
            {
                _context.GradeOptions.Remove(grade);
                await _context.SaveChangesAsync();
                SetStatusMessage("年级已删除。", "warning");
            }

            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostDeleteClassAsync(int id)
        {
            var cls = await _context.ClassGroups.FindAsync(id);
            if (cls != null)
            {
                _context.ClassGroups.Remove(cls);
                await _context.SaveChangesAsync();
                SetStatusMessage("班级已删除。", "warning");
            }

            return RedirectToPage();
        }

        private async Task NotifyAllUsersAsync(string title, string content)
        {
            var receiverIds = await _context.Users
                .Select(u => u.UserId)
                .ToListAsync();

            if (receiverIds.Count == 0)
            {
                return;
            }

            var now = DateTime.Now;
            var senderId = CurrentUserId;

            var messages = receiverIds.Select(id => new Message
            {
                SenderId = senderId,
                ReceiverId = id,
                Subject = $"系统公告：{title}",
                Content = content,
                Category = "Announcement",
                CreatedAt = now
            });

            _context.Messages.AddRange(messages);
            await _context.SaveChangesAsync();
        }

        private static string NormalizeName(string? value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }

        private void SetStatusMessage(string message, string type = "success")
        {
            TempData["StatusMessage"] = message;
            TempData["StatusType"] = type;
        }
    }
}
