using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MyStudyPlanSystem.Data;
using MyStudyPlanSystem.Models;
using System.Security.Claims;

namespace MyStudyPlanSystem.Pages.Admin.Users
{
    [Authorize(Policy = "RequireAdminOrTeacherRole")]
    public class IndexModel : PageModel
    {
        private static readonly HashSet<string> ReservedClassNames = new(StringComparer.OrdinalIgnoreCase)
        {
            "管理员",
            "教师",
            "学生",
            "Admin",
            "Teacher",
            "Student"
        };

        private readonly AppDbContext _context;

        public IndexModel(AppDbContext context)
        {
            _context = context;
        }

        public IList<User> Users { get; set; } = new List<User>();
        public IList<MajorOption> Majors { get; set; } = new List<MajorOption>();
        public IList<GradeOption> Grades { get; set; } = new List<GradeOption>();
        public IList<ClassGroup> Classes { get; set; } = new List<ClassGroup>();
        public int VisibleUserCount => Users.Count;
        public int StudentCount => Users.Count(u => u.Role == "Student");
        public int TeacherCount => Users.Count(u => u.Role == "Teacher");
        public int AdminCount => Users.Count(u => u.Role == "Admin");
        public bool CanCreateUsers => User.IsInRole("Admin");
        public bool CanDeleteUsers => User.IsInRole("Admin");
        public bool IsTeacherView => User.IsInRole("Teacher") && !User.IsInRole("Admin");

        [BindProperty, ValidateNever]
        public NewUserInput NewUser { get; set; } = new();

        [BindProperty, ValidateNever]
        public EditUserInput EditUser { get; set; } = new();

        public bool OpenCreatePanel { get; set; }
        public int? OpenEditUserId { get; set; }

        public class NewUserInput
        {
            public string Username { get; set; } = string.Empty;
            public string RealName { get; set; } = string.Empty;
            public string Password { get; set; } = string.Empty;
            public string Role { get; set; } = "Student";
            public string? Major { get; set; }
            public string? Grade { get; set; }
            public string? ClassName { get; set; }
        }

        public class EditUserInput
        {
            public int UserId { get; set; }
            public string RealName { get; set; } = string.Empty;
            public string Role { get; set; } = "Student";
            public string? Major { get; set; }
            public string? Grade { get; set; }
            public string? ClassName { get; set; }
            public string? NewPassword { get; set; }
        }

        private string CurrentRole => User.FindFirst(ClaimTypes.Role)?.Value ?? string.Empty;
        private int CurrentUserId => int.TryParse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value, out var id) ? id : 0;

        public async Task OnGetAsync()
        {
            await LoadDataAsync();
        }

        public IReadOnlyList<string> GetMajorNames(string? currentValue = null)
        {
            return MergeCurrentValue(Majors.Select(m => m.Name), currentValue);
        }

        public IReadOnlyList<string> GetGradeNames(string? currentValue = null)
        {
            return MergeCurrentValue(Grades.Select(g => g.Name), currentValue);
        }

        public IReadOnlyList<string> GetClassNames(string? currentValue = null)
        {
            return MergeCurrentValue(Classes.Select(c => c.Name), currentValue);
        }

        public async Task<IActionResult> OnPostCreateAsync()
        {
            if (!CanCreateUsers)
            {
                return Forbid();
            }

            NormalizeCreateInput();

            NewUser.Role = NormalizeRole(NewUser.Role);

            var major = NewUser.Major;
            var grade = NewUser.Grade;
            var className = NewUser.ClassName;
            ApplyRoleSpecificFields(NewUser.Role, ref major, ref grade, ref className);
            NewUser.Major = major;
            NewUser.Grade = grade;
            NewUser.ClassName = className;

            ValidateCreateInput();
            await ValidateUserSelectionsAsync(NewUser.Role, NewUser.Major, NewUser.Grade, NewUser.ClassName, nameof(NewUser));

            if (await _context.Users.AnyAsync(u => u.Username == NewUser.Username))
            {
                ModelState.AddModelError($"{nameof(NewUser)}.{nameof(NewUser.Username)}", "该账号已存在");
            }

            if (!ModelState.IsValid)
            {
                OpenCreatePanel = true;
                await LoadDataAsync();
                return Page();
            }

            _context.Users.Add(new User
            {
                Username = NewUser.Username,
                RealName = NewUser.RealName,
                Password = NewUser.Password,
                Role = NewUser.Role,
                Major = NewUser.Major,
                Grade = NewUser.Grade,
                ClassName = NewUser.ClassName,
                CreatedAt = DateTime.Now
            });

            await _context.SaveChangesAsync();
            SetStatusMessage("账号已创建。");
            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostUpdateAsync()
        {
            var user = await _context.Users.FindAsync(EditUser.UserId);
            if (user == null)
            {
                return RedirectToPage();
            }

            if (IsTeacherView && (user.Role != "Student" || !await CanTeacherManageStudentAsync(user.UserId)))
            {
                return Forbid();
            }

            NormalizeEditInput();

            EditUser.Role = CanCreateUsers
                ? NormalizeRole(EditUser.Role)
                : user.Role;

            var major = EditUser.Major;
            var grade = EditUser.Grade;
            var className = EditUser.ClassName;
            ApplyRoleSpecificFields(EditUser.Role, ref major, ref grade, ref className);
            EditUser.Major = major;
            EditUser.Grade = grade;
            EditUser.ClassName = className;

            ValidateEditInput();
            await ValidateUserSelectionsAsync(EditUser.Role, EditUser.Major, EditUser.Grade, EditUser.ClassName, nameof(EditUser));

            if (!ModelState.IsValid)
            {
                OpenEditUserId = EditUser.UserId;
                await LoadDataAsync();
                return Page();
            }

            user.RealName = EditUser.RealName;
            user.Role = EditUser.Role;
            user.Major = EditUser.Major;
            user.Grade = EditUser.Grade;
            user.ClassName = EditUser.ClassName;

            if (!string.IsNullOrWhiteSpace(EditUser.NewPassword))
            {
                user.Password = EditUser.NewPassword;
            }

            await _context.SaveChangesAsync();
            SetStatusMessage("账号信息已更新。");
            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostDeleteAsync(int id)
        {
            if (!CanDeleteUsers)
            {
                return Forbid();
            }

            var user = await _context.Users.FindAsync(id);
            if (user == null)
            {
                return RedirectToPage();
            }

            var currentUserId = CurrentUserId;
            if (user.UserId == currentUserId)
            {
                return RedirectToPage();
            }

            var relatedMessageIds = await _context.Messages
                .Where(m => m.SenderId == id || m.ReceiverId == id)
                .Select(m => m.MessageId)
                .ToListAsync();

            var relatedReplies = await _context.MessageReplies
                .Where(r => r.SenderId == id || relatedMessageIds.Contains(r.MessageId))
                .ToListAsync();

            if (relatedReplies.Count > 0)
            {
                _context.MessageReplies.RemoveRange(relatedReplies);
            }

            if (relatedMessageIds.Count > 0)
            {
                var messages = await _context.Messages
                    .Where(m => relatedMessageIds.Contains(m.MessageId))
                    .ToListAsync();
                _context.Messages.RemoveRange(messages);
            }

            _context.Users.Remove(user);
            await _context.SaveChangesAsync();
            SetStatusMessage("账号已删除。", "warning");
            return RedirectToPage();
        }

        private async Task LoadDataAsync()
        {
            var query = _context.Users.AsQueryable();

            if (IsTeacherView)
            {
                var managedStudentIds = BuildTeacherManagedStudentIdsQuery();
                query = query.Where(u => u.Role == "Student" && managedStudentIds.Contains(u.UserId));
            }

            Users = await query
                .OrderBy(u => u.UserId)
                .ToListAsync();

            Majors = await _context.MajorOptions.OrderBy(m => m.Name).ToListAsync();
            Grades = await _context.GradeOptions.OrderBy(g => g.Name).ToListAsync();
            Classes = await _context.ClassGroups
                .Where(c => !ReservedClassNames.Contains(c.Name))
                .OrderBy(c => c.Name)
                .ToListAsync();
        }

        private IQueryable<int> BuildTeacherManagedStudentIdsQuery()
        {
            if (CurrentUserId <= 0)
            {
                return _context.Users.Where(u => false).Select(u => u.UserId);
            }

            var courseIds = _context.Courses
                .Where(c => c.TeacherId == CurrentUserId)
                .Select(c => c.CourseId);

            return _context.StudyPlans
                .Where(p => p.CourseId.HasValue && courseIds.Contains(p.CourseId.Value))
                .Select(p => p.StudentId)
                .Distinct();
        }

        private Task<bool> CanTeacherManageStudentAsync(int studentId)
        {
            return BuildTeacherManagedStudentIdsQuery().AnyAsync(id => id == studentId);
        }

        private void NormalizeCreateInput()
        {
            NewUser.Username = NormalizeRequiredText(NewUser.Username);
            NewUser.RealName = NormalizeRequiredText(NewUser.RealName);
            NewUser.Password = NormalizeRequiredText(NewUser.Password);
            NewUser.Major = NormalizeSelection(NewUser.Major);
            NewUser.Grade = NormalizeSelection(NewUser.Grade);
            NewUser.ClassName = NormalizeSelection(NewUser.ClassName);
        }

        private void NormalizeEditInput()
        {
            EditUser.RealName = NormalizeRequiredText(EditUser.RealName);
            EditUser.NewPassword = NormalizeSelection(EditUser.NewPassword);
            EditUser.Major = NormalizeSelection(EditUser.Major);
            EditUser.Grade = NormalizeSelection(EditUser.Grade);
            EditUser.ClassName = NormalizeSelection(EditUser.ClassName);
        }

        private void ValidateCreateInput()
        {
            if (string.IsNullOrWhiteSpace(NewUser.Username))
            {
                ModelState.AddModelError($"{nameof(NewUser)}.{nameof(NewUser.Username)}", "请输入账号");
            }
            else if (!System.Text.RegularExpressions.Regex.IsMatch(NewUser.Username, @"^\d{8}$"))
            {
                ModelState.AddModelError($"{nameof(NewUser)}.{nameof(NewUser.Username)}", "账号必须是 8 位数字");
            }

            if (string.IsNullOrWhiteSpace(NewUser.RealName))
            {
                ModelState.AddModelError($"{nameof(NewUser)}.{nameof(NewUser.RealName)}", "请输入真实姓名");
            }
            else if (NewUser.RealName.Length > 50)
            {
                ModelState.AddModelError($"{nameof(NewUser)}.{nameof(NewUser.RealName)}", "真实姓名长度不能超过 50 个字符");
            }

            if (string.IsNullOrWhiteSpace(NewUser.Password))
            {
                ModelState.AddModelError($"{nameof(NewUser)}.{nameof(NewUser.Password)}", "请输入初始密码");
            }
            else if (NewUser.Password.Length < 6 || NewUser.Password.Length > 100)
            {
                ModelState.AddModelError($"{nameof(NewUser)}.{nameof(NewUser.Password)}", "密码长度至少 6 位");
            }

            if (string.IsNullOrWhiteSpace(NewUser.Role))
            {
                ModelState.AddModelError($"{nameof(NewUser)}.{nameof(NewUser.Role)}", "请选择角色");
            }
        }

        private void ValidateEditInput()
        {
            if (EditUser.UserId <= 0)
            {
                ModelState.AddModelError(string.Empty, "缺少用户标识");
            }

            if (string.IsNullOrWhiteSpace(EditUser.RealName))
            {
                ModelState.AddModelError($"{nameof(EditUser)}.{nameof(EditUser.RealName)}", "请输入真实姓名");
            }
            else if (EditUser.RealName.Length > 50)
            {
                ModelState.AddModelError($"{nameof(EditUser)}.{nameof(EditUser.RealName)}", "真实姓名长度不能超过 50 个字符");
            }

            if (string.IsNullOrWhiteSpace(EditUser.Role))
            {
                ModelState.AddModelError($"{nameof(EditUser)}.{nameof(EditUser.Role)}", "请选择角色");
            }

            if (!string.IsNullOrWhiteSpace(EditUser.NewPassword) &&
                (EditUser.NewPassword.Length < 6 || EditUser.NewPassword.Length > 100))
            {
                ModelState.AddModelError($"{nameof(EditUser)}.{nameof(EditUser.NewPassword)}", "密码长度至少 6 位");
            }
        }

        private async Task ValidateUserSelectionsAsync(string role, string? major, string? grade, string? className, string modelPrefix)
        {
            if (!string.Equals(role, "Student", StringComparison.OrdinalIgnoreCase))
            {
                return;
            }

            var majorLookup = await LoadNormalizedLookupAsync(_context.MajorOptions.Select(m => m.Name));
            var gradeLookup = await LoadNormalizedLookupAsync(_context.GradeOptions.Select(g => g.Name));
            var classLookup = await LoadNormalizedLookupAsync(
                _context.ClassGroups
                    .Where(c => !ReservedClassNames.Contains(c.Name))
                    .Select(c => c.Name));

            ValidateSelection(modelPrefix, nameof(NewUserInput.Major), "专业", major, majorLookup);
            ValidateSelection(modelPrefix, nameof(NewUserInput.Grade), "年级", grade, gradeLookup);
            ValidateSelection(modelPrefix, nameof(NewUserInput.ClassName), "班级", className, classLookup);
        }

        private void ValidateSelection(string modelPrefix, string propertyName, string displayName, string? value, HashSet<string> lookup)
        {
            if (lookup.Count == 0)
            {
                ModelState.AddModelError(string.Empty, $"请先由管理员添加{displayName}");
                return;
            }

            if (string.IsNullOrWhiteSpace(value))
            {
                ModelState.AddModelError($"{modelPrefix}.{propertyName}", $"请选择{displayName}");
                return;
            }

            if (!lookup.Contains(value))
            {
                ModelState.AddModelError($"{modelPrefix}.{propertyName}", $"所选{displayName}不存在，请先由管理员添加");
            }
        }

        private static async Task<HashSet<string>> LoadNormalizedLookupAsync(IQueryable<string> query)
        {
            return (await query.ToListAsync())
                .Select(NormalizeSelection)
                .Where(value => !string.IsNullOrWhiteSpace(value))
                .Cast<string>()
                .ToHashSet(StringComparer.OrdinalIgnoreCase);
        }

        private static string NormalizeRequiredText(string? value)
        {
            return value?.Trim() ?? string.Empty;
        }

        private static string? NormalizeSelection(string? value)
        {
            return string.IsNullOrWhiteSpace(value) ? null : value.Trim();
        }

        private static string NormalizeRole(string? role)
        {
            if (string.Equals(role, "Student", StringComparison.OrdinalIgnoreCase))
            {
                return "Student";
            }

            if (string.Equals(role, "Teacher", StringComparison.OrdinalIgnoreCase))
            {
                return "Teacher";
            }

            if (string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase))
            {
                return "Admin";
            }

            return string.Empty;
        }

        private static void ApplyRoleSpecificFields(string role, ref string? major, ref string? grade, ref string? className)
        {
            if (!string.Equals(role, "Student", StringComparison.OrdinalIgnoreCase))
            {
                major = null;
                grade = null;
                className = null;
            }
        }

        private static IReadOnlyList<string> MergeCurrentValue(IEnumerable<string> source, string? currentValue)
        {
            var values = source
                .Select(NormalizeSelection)
                .Where(value => !string.IsNullOrWhiteSpace(value))
                .Cast<string>()
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(value => value)
                .ToList();

            if (!string.IsNullOrWhiteSpace(currentValue) &&
                !values.Contains(currentValue, StringComparer.OrdinalIgnoreCase))
            {
                values.Insert(0, currentValue);
            }

            return values;
        }

        private void SetStatusMessage(string message, string type = "success")
        {
            TempData["StatusMessage"] = message;
            TempData["StatusType"] = type;
        }
    }
}
