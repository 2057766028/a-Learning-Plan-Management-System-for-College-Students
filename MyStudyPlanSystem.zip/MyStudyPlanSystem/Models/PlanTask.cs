using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStudyPlanSystem.Models
{
    public class PlanTask
    {
        [Key]
        public int PlanTaskId { get; set; }

        public int PlanId { get; set; }

        [ForeignKey("PlanId")]
        public StudyPlan? StudyPlan { get; set; }

        public int TaskId { get; set; }

        [ForeignKey("TaskId")]
        public CourseTask? CourseTask { get; set; }

        public required DateTime PlannedDate { get; set; } // 计划完成日期

        public bool IsCompleted { get; set; } = false;

        public DateTime? CompletedDate { get; set; }

        [StringLength(500)]
        public string? Notes { get; set; }
    }
}
