using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStudyPlanSystem.Models
{
    public class CourseTask   //课程任务
    {
        [Key]
        public int TaskId { get; set; }

        [Required]
        [StringLength(200)]
        public required string TaskName { get; set; }

        [StringLength(1000)]
        public string? Description { get; set; }

        public int CourseId { get; set; }

        [ForeignKey("CourseId")]
        public Course? Course { get; set; }

        public int EstimatedHours { get; set; } // 预计完成小时数

        [StringLength(500)]
        public string? ResourceUrl { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        // 导航属性
        public ICollection<PlanTask> PlanTasks { get; set; } = new List<PlanTask>();
    }
}
