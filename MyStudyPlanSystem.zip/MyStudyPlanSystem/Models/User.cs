using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MyStudyPlanSystem.Models
{
    public class User
    {
        [Key]
        public int UserId { get; set; }

        [Required]
        [StringLength(50)]
        [RegularExpression(@"^\d{8}$", ErrorMessage = "账号必须是 8 位数字")]
        public required string Username { get; set; }

        [Required]
        [StringLength(100)]
        public required string Password { get; set; }

        [Required]
        [StringLength(50)]
        public required string RealName { get; set; }

        [Required]
        public required string Role { get; set; }

        [StringLength(100)]
        public string? Major { get; set; }

        [StringLength(50)]
        public string? Grade { get; set; }

        [StringLength(50)]
        public string? ClassName { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        public ICollection<Course> Courses { get; set; } = new List<Course>();
        public ICollection<StudyPlan> StudyPlans { get; set; } = new List<StudyPlan>();
        public ICollection<Message> SentMessages { get; set; } = new List<Message>();
        public ICollection<Message> ReceivedMessages { get; set; } = new List<Message>();
    }
}
