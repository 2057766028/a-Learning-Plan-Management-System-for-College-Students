using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MyStudyPlanSystem.Models
{
    public class Term
    {
        [Key]
        public int TermId { get; set; }

        [Required]
        [StringLength(50)]
        public required string Name { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public ICollection<ClassGroup> Classes { get; set; } = new List<ClassGroup>();
    }
}
