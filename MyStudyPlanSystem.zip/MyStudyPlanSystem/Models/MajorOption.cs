using System.ComponentModel.DataAnnotations;

namespace MyStudyPlanSystem.Models
{
    public class MajorOption
    {
        [Key]
        public int MajorOptionId { get; set; }

        [Required]
        [StringLength(100)]
        public required string Name { get; set; }
    }
}
