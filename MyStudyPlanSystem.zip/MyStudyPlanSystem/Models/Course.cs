using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MyStudyPlanSystem.Models
{
    public class Course
    {
        [Key]
        public int CourseId { get; set; }

        [Required]
        [StringLength(30)]
        public required string CourseCode { get; set; }

        [Required]
        [StringLength(100)]
        public required string CourseName { get; set; }

        [StringLength(500)]
        public string? Description { get; set; }

        [StringLength(300)]
        public string? MaterialPath { get; set; }

        public int TeacherId { get; set; }

        [ForeignKey("TeacherId")]
        public required User Teacher { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        public ICollection<CourseTask> Tasks { get; set; } = new List<CourseTask>();
    }
}
