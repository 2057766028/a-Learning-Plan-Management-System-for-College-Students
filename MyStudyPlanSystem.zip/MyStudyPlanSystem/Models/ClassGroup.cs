using System.ComponentModel.DataAnnotations;

namespace MyStudyPlanSystem.Models
{
    public class ClassGroup
    {
        [Key]
        public int ClassGroupId { get; set; }

        [Required]
        [StringLength(50)]
        public required string Name { get; set; }

        public int? TermId { get; set; }

        public Term? Term { get; set; }
    }
}
