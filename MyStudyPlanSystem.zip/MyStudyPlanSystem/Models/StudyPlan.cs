using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStudyPlanSystem.Models
{
    public class StudyPlan    //学习计划
    {
        [Key]
        public int PlanId { get; set; }

        [Required]
        [StringLength(200)]
        public required string PlanName { get; set; }

        [StringLength(1000)]
        public string? Description { get; set; }

        public int StudentId { get; set; }

        [ForeignKey("StudentId")]
        public User? Student { get; set; }

        public int? CourseId { get; set; }

        [ForeignKey("CourseId")]
        public Course? Course { get; set; }

        public required DateTime StartDate { get; set; }

        public required DateTime EndDate { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        // 导航属性
        public ICollection<PlanTask> PlanTasks { get; set; } = new List<PlanTask>();
    }
}
