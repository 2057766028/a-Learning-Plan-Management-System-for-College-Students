using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MyStudyPlanSystem.Models
{
    public class MessageReply
    {
        [Key]
        public int MessageReplyId { get; set; }

        public int MessageId { get; set; }

        [ForeignKey(nameof(MessageId))]
        public Message? Message { get; set; }

        public int SenderId { get; set; }

        [ForeignKey(nameof(SenderId))]
        public User? Sender { get; set; }

        [Required]
        [StringLength(2000)]
        public required string Content { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}
