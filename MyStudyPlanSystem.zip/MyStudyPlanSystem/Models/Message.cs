using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStudyPlanSystem.Models
{
    public class Message  //师生消息
    {
        [Key]
        public int MessageId { get; set; }

        public int SenderId { get; set; }

        [ForeignKey("SenderId")]
        public User? Sender { get; set; }

        public int ReceiverId { get; set; }

        [ForeignKey("ReceiverId")]
        public User? Receiver { get; set; }

        [StringLength(200)]
        public string Subject { get; set; } = string.Empty;

        [Required]
        [StringLength(2000)]
        public required string Content { get; set; }

        [StringLength(50)]
        public string Category { get; set; } = "General";

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        public bool IsRead { get; set; } = false;

        [StringLength(2000)]
        public string? Reply { get; set; }

        public DateTime? RepliedAt { get; set; }

        public ICollection<MessageReply> Replies { get; set; } = new List<MessageReply>();
    }
}
