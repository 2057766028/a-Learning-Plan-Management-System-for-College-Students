using System.ComponentModel.DataAnnotations;

namespace MyStudyPlanSystem.Models
{
    public class GradeOption
    {
        [Key]
        public int GradeOptionId { get; set; }

        [Required]
        [StringLength(50)]
        public required string Name { get; set; }
    }
}
