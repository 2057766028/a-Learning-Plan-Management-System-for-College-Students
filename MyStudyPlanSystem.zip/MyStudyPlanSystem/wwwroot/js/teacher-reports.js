﻿(() => {
    const pageData = window.teacherReportPageData || {};
    const overallData = pageData.overall || { completed: 0, pending: 0 };
    const payload = pageData.payload || {};
    const allTaskRows = payload.allTaskRows || [];
    const modalElement = document.getElementById("reportDetailModal");
    const modalTitle = document.getElementById("reportDetailModalLabel");
    const modalSubtitle = document.getElementById("reportDetailModalSubtitle");
    const modalContent = document.getElementById("reportDetailModalContent");
    const modal = modalElement && window.bootstrap
        ? bootstrap.Modal.getOrCreateInstance(modalElement)
        : null;
    const activeCharts = [];

    const escapeHtml = (value) => {
        const source = `${value ?? ""}`;
        return source
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/\"/g, "&quot;")
            .replace(/'/g, "&#39;");
    };

    const formatPercent = (value) => `${Number(value || 0).toFixed(1)}%`;
    const formatDate = (value) => value ? new Date(value).toLocaleDateString("zh-CN") : "-";
    const progressBar = (value) => `
        <div class="progress report-inline-progress mt-2">
            <div class="progress-bar bg-primary" role="progressbar" style="width:${Number(value || 0).toFixed(1)}%"></div>
        </div>`;
    const buildStatusPill = (label, tone = "primary") => `<span class="report-status-pill report-status-pill-${tone}">${escapeHtml(label)}</span>`;

    const destroyCharts = () => {
        while (activeCharts.length > 0) {
            activeCharts.pop().destroy();
        }
    };

    const createChart = (canvasId, config) => {
        const canvas = document.getElementById(canvasId);
        if (!canvas) {
            return;
        }

        activeCharts.push(new Chart(canvas, config));
    };

    const createDoughnut = (canvasId, completed, pending, showLegend = true) => {
        createChart(canvasId, {
            type: "doughnut",
            data: {
                labels: ["已完成", "待完成"],
                datasets: [{
                    data: [completed, pending],
                    backgroundColor: ["#2563eb", "#bfdbfe"],
                    borderWidth: 0,
                    hoverOffset: 6
                }]
            },
            options: {
                cutout: "76%",
                plugins: {
                    legend: {
                        display: showLegend,
                        position: "bottom",
                        labels: {
                            usePointStyle: true,
                            padding: 16
                        }
                    }
                }
            }
        });
    };

    const createBar = (canvasId, labels, values, label) => {
        createChart(canvasId, {
            type: "bar",
            data: {
                labels,
                datasets: [{
                    label,
                    data: values,
                    borderRadius: 8,
                    backgroundColor: "rgba(37, 99, 235, 0.82)",
                    borderColor: "#2563eb",
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            callback: (value) => `${value}%`
                        },
                        grid: {
                            color: "rgba(148, 163, 184, 0.18)"
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    };

    const buildDataAttributes = (attributes = {}) => Object.entries(attributes)
        .map(([key, value]) => `${key}="${escapeHtml(value)}"`)
        .join(" ");

    const renderKpiGrid = (items) => `
        <div class="report-modal-kpi-grid">
            ${items.map(item => {
                const tag = item.interactive ? "button" : "div";
                const attrs = item.interactive ? buildDataAttributes(item.attributes) : "";

                return `
                <${tag} class="report-modal-kpi ${item.interactive ? "report-modal-kpi-button" : ""}" ${attrs}>
                    <div class="report-modal-kpi-label">${escapeHtml(item.label)}</div>
                    <div class="report-modal-kpi-value">${escapeHtml(item.value)}</div>
                </${tag}>`;
            }).join("")}
        </div>`;

    const renderStudentRowTable = (rows) => {
        if (!rows.length) {
            return '<div class="report-empty">暂无数据。</div>';
        }

        return `
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th>学生</th>
                            <th>课程</th>
                            <th>总任务</th>
                            <th>已完成</th>
                            <th>待完成</th>
                            <th>逾期未完成</th>
                            <th>完成率</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rows.map(row => `
                            <tr>
                                <td>
                                    <button type="button" class="report-link-button" data-modal-action="student" data-student-id="${row.studentId}">${escapeHtml(row.studentName)}</button>
                                    <div class="small text-muted font-monospace">${escapeHtml(row.studentNumber)}</div>
                                </td>
                                <td>
                                    <button type="button" class="report-link-button" data-modal-action="course" data-course-id="${row.courseId}">${escapeHtml(row.courseName)}</button>
                                    <div class="small text-muted font-monospace">${escapeHtml(row.courseCode)}</div>
                                </td>
                                <td>${row.totalTasks}</td>
                                <td>${row.completedTasks}</td>
                                <td>${row.pendingTasks}</td>
                                <td>${row.overdueTasks}</td>
                                <td>
                                    <div class="fw-semibold">${formatPercent(row.completionRate)}</div>
                                    ${progressBar(row.completionRate)}
                                </td>
                            </tr>`).join("")}
                    </tbody>
                </table>
            </div>`;
    };

    const renderTaskRowTable = (rows, mode, options = {}) => {
        if (!rows.length) {
            const emptyLabel = mode === "completed"
                ? "已完成"
                : mode === "overdue"
                    ? "逾期未完成"
                    : "任务";

            return `<div class="report-empty">当前暂无${emptyLabel}数据。</div>`;
        }

        const isCompletedMode = mode === "completed";
        const isAllMode = mode === "all";
        const showStudent = options.showStudent !== false;
        const showCourse = options.showCourse !== false;

        return `
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            ${showStudent ? "<th>学生</th>" : ""}
                            ${showCourse ? "<th>课程</th>" : ""}
                            <th>任务</th>
                            <th>计划完成</th>
                            <th>${isAllMode ? "补充信息" : isCompletedMode ? "完成时间" : "逾期时长"}</th>
                            <th>状态</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rows.map(row => `
                            <tr>
                                ${showStudent ? `<td>
                                    <button type="button" class="report-link-button" data-modal-action="student" data-student-id="${row.studentId}">${escapeHtml(row.studentName)}</button>
                                    <div class="small text-muted font-monospace">${escapeHtml(row.studentNumber)}</div>
                                </td>` : ""}
                                ${showCourse ? `<td>
                                    <button type="button" class="report-link-button" data-modal-action="course" data-course-id="${row.courseId}">${escapeHtml(row.courseName)}</button>
                                    <div class="small text-muted font-monospace">${escapeHtml(row.courseCode)}</div>
                                </td>` : ""}
                                <td>
                                    <div class="fw-semibold text-dark">${escapeHtml(row.taskName)}</div>
                                    ${row.notes ? `<div class="small text-muted mt-1">${escapeHtml(row.notes)}</div>` : ""}
                                </td>
                                <td>${formatDate(row.plannedDate)}</td>
                                <td>
                                    ${isAllMode
                                        ? (row.isCompleted
                                            ? `<span class="fw-semibold text-success-emphasis">${formatDate(row.completedDate)}</span>`
                                            : row.overdueDays > 0
                                                ? `<span class="fw-semibold text-warning-emphasis">已逾期 ${Number(row.overdueDays || 0)} 天</span>`
                                                : `<span class="text-muted">等待完成</span>`)
                                        : isCompletedMode
                                        ? `<span class="fw-semibold text-success-emphasis">${formatDate(row.completedDate)}</span>`
                                        : `<span class="fw-semibold text-warning-emphasis">${Number(row.overdueDays || 0)} 天</span>`}
                                </td>
                                <td>
                                    ${isAllMode
                                        ? (row.isCompleted
                                            ? buildStatusPill("已完成", "success")
                                            : row.overdueDays > 0
                                                ? buildStatusPill("已逾期", "warning")
                                                : buildStatusPill("待完成"))
                                        : isCompletedMode
                                            ? buildStatusPill("已完成", "success")
                                            : buildStatusPill("已逾期", "warning")}
                                </td>
                            </tr>`).join("")}
                    </tbody>
                </table>
            </div>`;
    };

    const renderManagedCoursesTable = (rows) => {
        if (!rows.length) {
            return '<div class="report-empty">暂无课程数据。</div>';
        }

        return `
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th>课程</th>
                            <th>创建时间</th>
                            <th>任务模板</th>
                            <th>已选学生</th>
                            <th>完成率</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rows.map(row => `
                            <tr>
                                <td>
                                    <button type="button" class="report-link-button" data-modal-action="course" data-course-id="${row.courseId}">${escapeHtml(row.courseName)}</button>
                                    <div class="small text-muted font-monospace">${escapeHtml(row.courseCode)}</div>
                                </td>
                                <td>${formatDate(row.createdAt)}</td>
                                <td>${row.taskTemplateCount}</td>
                                <td>${row.studentCount}</td>
                                <td>
                                    <div class="fw-semibold">${formatPercent(row.completionRate)}</div>
                                    ${progressBar(row.completionRate)}
                                </td>
                            </tr>`).join("")}
                    </tbody>
                </table>
            </div>`;
    };

    const renderManagedStudentsTable = (rows) => {
        if (!rows.length) {
            return '<div class="report-empty">暂无学生数据。</div>';
        }

        return `
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th>学生</th>
                            <th>专业 / 年级 / 班级</th>
                            <th>课程数</th>
                            <th>总任务</th>
                            <th>完成率</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rows.map(row => `
                            <tr>
                                <td>
                                    <button type="button" class="report-link-button" data-modal-action="student" data-student-id="${row.studentId}">${escapeHtml(row.studentName)}</button>
                                    <div class="small text-muted font-monospace">${escapeHtml(row.studentNumber)}</div>
                                </td>
                                <td>
                                    <div>${escapeHtml(row.major || "未设置专业")}</div>
                                    <div class="small text-muted">${escapeHtml(row.grade || "未设置年级")}</div>
                                    <div class="small text-muted">${escapeHtml(row.className || "未设置班级")}</div>
                                </td>
                                <td>${row.courseCount}</td>
                                <td>${row.totalTasks}</td>
                                <td>
                                    <div class="fw-semibold">${formatPercent(row.completionRate)}</div>
                                    ${progressBar(row.completionRate)}
                                </td>
                            </tr>`).join("")}
                    </tbody>
                </table>
            </div>`;
    };

    const openModal = ({ title, subtitle = "", bodyHtml, afterShow }) => {
        destroyCharts();
        if (!modalTitle || !modalSubtitle || !modalContent) {
            return;
        }

        modalTitle.textContent = title;
        modalSubtitle.textContent = subtitle;
        modalContent.innerHTML = bodyHtml;
        modal?.show();
        if (afterShow) {
            window.requestAnimationFrame(afterShow);
        }
    };

    const setDrilldown = (title, bodyHtml) => {
        const titleElement = document.getElementById("reportDetailDrilldownTitle");
        const bodyElement = document.getElementById("reportDetailDrilldownBody");

        if (!titleElement || !bodyElement) {
            return;
        }

        titleElement.textContent = title;
        bodyElement.innerHTML = bodyHtml;
    };

    const setActiveMetric = (action, id, metric) => {
        modalContent?.querySelectorAll(`[data-modal-action="${action}"]`).forEach(element => {
            const matches = element.getAttribute("data-metric") === metric &&
                (element.getAttribute("data-course-id") === `${id}` || element.getAttribute("data-student-id") === `${id}`);

            element.classList.toggle("report-modal-kpi-active", matches);
        });
    };

    const renderCourseMetric = (courseId, metric) => {
        const detail = (payload.courseDetails || []).find(item => item.courseId === Number(courseId));
        if (!detail) {
            return;
        }

        const taskRows = allTaskRows
            .filter(row => row.courseId === Number(courseId))
            .sort((left, right) => new Date(left.plannedDate) - new Date(right.plannedDate));

        if (metric === "students") {
            setDrilldown("选课学生", renderStudentRowTable(detail.students || []));
        }
        else if (metric === "tasks") {
            setDrilldown("全部任务明细", renderTaskRowTable(taskRows, "all", { showCourse: false }));
        }
        else if (metric === "completed") {
            setDrilldown("已完成任务明细", renderTaskRowTable(taskRows.filter(row => row.isCompleted), "completed", { showCourse: false }));
        }
        else if (metric === "overdue") {
            setDrilldown("逾期未完成任务明细", renderTaskRowTable(taskRows.filter(row => Number(row.overdueDays || 0) > 0), "overdue", { showCourse: false }));
        }

        setActiveMetric("course-metric", courseId, metric);
    };

    const renderStudentMetric = (studentId, metric) => {
        const detail = (payload.studentDetails || []).find(item => item.studentId === Number(studentId));
        if (!detail) {
            return;
        }

        const taskRows = allTaskRows
            .filter(row => row.studentId === Number(studentId))
            .sort((left, right) => new Date(left.plannedDate) - new Date(right.plannedDate));

        if (metric === "courses") {
            setDrilldown("课程明细", renderStudentRowTable(detail.courses || []));
        }
        else if (metric === "tasks") {
            setDrilldown("全部任务明细", renderTaskRowTable(taskRows, "all", { showStudent: false }));
        }
        else if (metric === "completed") {
            setDrilldown("已完成任务明细", renderTaskRowTable(taskRows.filter(row => row.isCompleted), "completed", { showStudent: false }));
        }
        else if (metric === "overdue") {
            setDrilldown("逾期未完成任务明细", renderTaskRowTable(taskRows.filter(row => Number(row.overdueDays || 0) > 0), "overdue", { showStudent: false }));
        }

        setActiveMetric("student-metric", studentId, metric);
    };

    const renderPanel = (panel) => {
        if (panel === "courses") {
            openModal({
                title: "已管理课程",
                subtitle: `当前共管理 ${payload.managedCourses?.length || 0} 门课程`,
                bodyHtml: renderManagedCoursesTable(payload.managedCourses || [])
            });
            return;
        }

        if (panel === "students") {
            openModal({
                title: "已选课学生",
                subtitle: `当前共涉及 ${payload.managedStudents?.length || 0} 名学生`,
                bodyHtml: renderManagedStudentsTable(payload.managedStudents || [])
            });
            return;
        }

        if (panel === "completed") {
            const rows = payload.completedTaskRows || [];
            openModal({
                title: "已完成任务明细",
                subtitle: `当前共统计到 ${rows.length} 项已完成任务`,
                bodyHtml: renderTaskRowTable(rows, "completed")
            });
            return;
        }

        if (panel === "overdue") {
            const rows = payload.overdueTaskRows || [];
            openModal({
                title: "逾期未完成任务明细",
                subtitle: `当前共统计到 ${rows.length} 项逾期任务`,
                bodyHtml: renderTaskRowTable(rows, "overdue")
            });
        }
    };

    const renderCourseDetail = (courseId) => {
        const detail = (payload.courseDetails || []).find(item => item.courseId === Number(courseId));
        if (!detail) {
            return;
        }

        const bodyHtml = `
            <div class="report-modal-stack">
                ${renderKpiGrid([
                    { label: "已选学生", value: detail.studentCount, interactive: true, attributes: { "data-modal-action": "course-metric", "data-course-id": detail.courseId, "data-metric": "students", type: "button" } },
                    { label: "总任务", value: detail.totalTasks, interactive: true, attributes: { "data-modal-action": "course-metric", "data-course-id": detail.courseId, "data-metric": "tasks", type: "button" } },
                    { label: "已完成", value: detail.completedTasks, interactive: true, attributes: { "data-modal-action": "course-metric", "data-course-id": detail.courseId, "data-metric": "completed", type: "button" } },
                    { label: "逾期未完成", value: detail.overdueTasks, interactive: true, attributes: { "data-modal-action": "course-metric", "data-course-id": detail.courseId, "data-metric": "overdue", type: "button" } }
                ])}
                <div class="row g-4">
                    <div class="col-lg-5">
                        <div class="report-modal-panel h-100">
                            <div class="report-panel-title">课程画像</div>
                            <div class="report-modal-meta">
                                <div><span>课程编号</span><strong>${escapeHtml(detail.courseCode)}</strong></div>
                                <div><span>待完成</span><strong>${detail.pendingTasks}</strong></div>
                                <div><span>完成率</span><strong>${formatPercent(detail.completionRate)}</strong></div>
                            </div>
                            <div class="report-doughnut-wrap mt-3">
                                <canvas id="courseDetailDoughnut" height="220"></canvas>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="report-modal-panel h-100">
                            <div class="report-panel-title">学生完成率分布</div>
                            <div class="report-bar-wrap">
                                <canvas id="courseDetailBar"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="report-modal-panel">
                    <div class="report-panel-title" id="reportDetailDrilldownTitle">选课学生</div>
                    <div id="reportDetailDrilldownBody">
                        ${renderStudentRowTable(detail.students || [])}
                    </div>
                </div>
            </div>`;

        openModal({
            title: detail.courseName,
            subtitle: `课程编号 ${detail.courseCode}`,
            bodyHtml,
            afterShow: () => {
                createDoughnut("courseDetailDoughnut", detail.completedTasks, detail.pendingTasks);
                createBar(
                    "courseDetailBar",
                    (detail.students || []).map(item => item.studentName),
                    (detail.students || []).map(item => Number(item.completionRate || 0)),
                    "完成率"
                );
                setActiveMetric("course-metric", detail.courseId, "students");
            }
        });
    };

    const renderStudentDetail = (studentId) => {
        const detail = (payload.studentDetails || []).find(item => item.studentId === Number(studentId));
        if (!detail) {
            return;
        }

        const bodyHtml = `
            <div class="report-modal-stack">
                ${renderKpiGrid([
                    { label: "课程数", value: detail.courseCount, interactive: true, attributes: { "data-modal-action": "student-metric", "data-student-id": detail.studentId, "data-metric": "courses", type: "button" } },
                    { label: "总任务", value: detail.totalTasks, interactive: true, attributes: { "data-modal-action": "student-metric", "data-student-id": detail.studentId, "data-metric": "tasks", type: "button" } },
                    { label: "已完成", value: detail.completedTasks, interactive: true, attributes: { "data-modal-action": "student-metric", "data-student-id": detail.studentId, "data-metric": "completed", type: "button" } },
                    { label: "逾期未完成", value: detail.overdueTasks, interactive: true, attributes: { "data-modal-action": "student-metric", "data-student-id": detail.studentId, "data-metric": "overdue", type: "button" } }
                ])}
                <div class="row g-4">
                    <div class="col-lg-5">
                        <div class="report-modal-panel h-100">
                            <div class="report-panel-title">学生画像</div>
                            <div class="report-modal-meta">
                                <div><span>学号</span><strong>${escapeHtml(detail.studentNumber)}</strong></div>
                                <div><span>专业</span><strong>${escapeHtml(detail.major || "未设置专业")}</strong></div>
                                <div><span>年级 / 班级</span><strong>${escapeHtml(detail.grade || "未设置年级")} / ${escapeHtml(detail.className || "未设置班级")}</strong></div>
                                <div><span>完成率</span><strong>${formatPercent(detail.completionRate)}</strong></div>
                            </div>
                            <div class="report-doughnut-wrap mt-3">
                                <canvas id="studentDetailDoughnut" height="220"></canvas>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="report-modal-panel h-100">
                            <div class="report-panel-title">各课程完成率</div>
                            <div class="report-bar-wrap">
                                <canvas id="studentDetailBar"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="report-modal-panel">
                    <div class="report-panel-title" id="reportDetailDrilldownTitle">课程明细</div>
                    <div id="reportDetailDrilldownBody">
                        ${renderStudentRowTable(detail.courses || [])}
                    </div>
                </div>
            </div>`;

        openModal({
            title: detail.studentName,
            subtitle: `学号 ${detail.studentNumber}`,
            bodyHtml,
            afterShow: () => {
                createDoughnut("studentDetailDoughnut", detail.completedTasks, detail.pendingTasks);
                createBar(
                    "studentDetailBar",
                    (detail.courses || []).map(item => item.courseName),
                    (detail.courses || []).map(item => Number(item.completionRate || 0)),
                    "完成率"
                );
                setActiveMetric("student-metric", detail.studentId, "courses");
            }
        });
    };

    document.querySelectorAll("[data-report-panel]").forEach(button => {
        button.addEventListener("click", () => renderPanel(button.getAttribute("data-report-panel")));
    });

    const bindRowAction = (selector, callback, attributeName) => {
        document.querySelectorAll(selector).forEach(element => {
            const invoke = () => callback(element.getAttribute(attributeName));
            element.addEventListener("click", invoke);
            element.addEventListener("keydown", event => {
                if (event.key === "Enter" || event.key === " ") {
                    event.preventDefault();
                    invoke();
                }
            });
        });
    };

    bindRowAction(".js-course-detail", renderCourseDetail, "data-course-id");
    bindRowAction(".js-student-detail", renderStudentDetail, "data-student-id");

    modalContent?.addEventListener("click", event => {
        const trigger = event.target.closest("[data-modal-action]");
        if (!trigger) {
            return;
        }

        const action = trigger.getAttribute("data-modal-action");
        if (action === "course") {
            renderCourseDetail(trigger.getAttribute("data-course-id"));
        }
        else if (action === "student") {
            renderStudentDetail(trigger.getAttribute("data-student-id"));
        }
        else if (action === "course-metric") {
            renderCourseMetric(trigger.getAttribute("data-course-id"), trigger.getAttribute("data-metric"));
        }
        else if (action === "student-metric") {
            renderStudentMetric(trigger.getAttribute("data-student-id"), trigger.getAttribute("data-metric"));
        }
    });

    if (overallData && (overallData.completed + overallData.pending) > 0) {
        createDoughnut("reportOverallChart", overallData.completed, overallData.pending, false);
    }
})();
