using System;

namespace MyStudyPlanSystem.Utils
{
    public static class ResourceUrlHelper
    {
        public static string? NormalizeForStorage(string? value)
        {
            return NormalizeCore(value);
        }

        public static string? ToNavigableUrl(string? value)
        {
            return NormalizeCore(value);
        }

        private static string? NormalizeCore(string? value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return null;
            }

            var normalized = value.Trim();

            if (normalized.StartsWith("~/", StringComparison.Ordinal))
            {
                return normalized[1..];
            }

            if (normalized.StartsWith("/", StringComparison.Ordinal))
            {
                return normalized;
            }

            if (Uri.TryCreate(normalized, UriKind.Absolute, out _))
            {
                return normalized;
            }

            if (normalized.StartsWith("//", StringComparison.Ordinal))
            {
                return $"https:{normalized}";
            }

            if (normalized.StartsWith("www.", StringComparison.OrdinalIgnoreCase) || LooksLikeDomain(normalized))
            {
                return $"https://{normalized}";
            }

            return normalized;
        }

        private static bool LooksLikeDomain(string value)
        {
            if (value.Contains(' ', StringComparison.Ordinal) ||
                value.StartsWith("./", StringComparison.Ordinal) ||
                value.StartsWith("../", StringComparison.Ordinal))
            {
                return false;
            }

            var boundary = value.IndexOfAny(new[] { '/', '?', '#' });
            var host = boundary >= 0 ? value[..boundary] : value;

            return host.Contains('.', StringComparison.Ordinal) &&
                   !host.Contains(':', StringComparison.Ordinal);
        }
    }
}
